/**
 * FESU-WW 2026 Election Portal
 * Secure Voting Application
 * Sacred Election Sanctuary
 */

// ============================================
// GLOBAL STATE MANAGEMENT
// ============================================
const AppState = {
    currentSection: 'auth-section',
    authStep: 1,
    sessionTimer: null,
    inactivityTimer: null,
    inactivityWarningTimer: null,
    sessionTimeRemaining: 900, // 15 minutes in seconds
    inactivityTimeRemaining: 30, // 30 seconds warning
    hasVoted: false,
    selections: {},
    voterInfo: {
        id: null,
        name: null,
        phoneEnding: null
    },
    auditLog: [],
    isAuthenticated: false
};

// ============================================
// MOCK DATA - CANDIDATES & VOTERS
// ============================================
const CANDIDATES = {
    'spirit-head': {
        'sh-001': { name: 'Emmanuel Okon', dept: 'Department of Law' },
        'sh-002': { name: 'Sarah Bassey', dept: 'Department of Medicine' },
        'sh-003': { name: 'David Etim', dept: 'Department of Engineering' }
    },
    'deputy-spirit-head': {
        'dsh-001': { name: 'Grace Akpan', dept: 'Department of Economics' },
        'dsh-002': { name: 'Michael Udo', dept: 'Department of Political Science' }
    },
    'scribe-general': {
        'sg-001': { name: 'Patience Essien', dept: 'Department of English' },
        'sg-002': { name: 'John Edet', dept: 'Department of Mass Communication' },
        'sg-003': { name: 'Mary Obot', dept: 'Department of History' }
    },
    'keeper-treasury': {
        'kt-001': { name: 'Joseph Akpan', dept: 'Department of Accounting' },
        'kt-002': { name: 'Esther Eno', dept: 'Department of Banking & Finance' }
    },
    'director-socials': {
        'ds-001': { name: 'Daniel Ibanga', dept: 'Department of Theatre Arts' },
        'ds-002': { name: 'Victoria Umo', dept: 'Department of Music' },
        'ds-003': { name: 'Samuel Ekpo', dept: 'Department of Fine Arts' }
    },
    'director-sports': {
        'dsp-001': { name: 'Peter Etim', dept: 'Department of Physical Education' },
        'dsp-002': { name: 'Glory Akpan', dept: 'Department of Human Kinetics' }
    },
    'director-welfare': {
        'dw-001': { name: 'Rose Ekanem', dept: 'Department of Social Work' },
        'dw-002': { name: 'Paul Bassey', dept: 'Department of Psychology' },
        'dw-003': { name: 'Blessing Udo', dept: 'Department of Nursing' }
    },
    'provost': {
        'pr-001': { name: 'Matthew Okon', dept: 'Department of Criminology' },
        'pr-002': { name: 'Faith Etim', dept: 'Department of Public Administration' }
    }
};

const VALID_VOTERS = [
    { id: 'FESU-2026-0001', name: 'John Ekureku', password: 'SecurePass123!', phoneEnding: '4589' },
    { id: 'FESU-2026-0002', name: 'Mary Bassey', password: 'Vote2026#Secure', phoneEnding: '6723' },
    { id: 'FESU-2026-0003', name: 'Emmanuel Okon', password: 'Democracy@FESU', phoneEnding: '8912' },
    { id: 'FESU-2026-0004', name: 'Grace Akpan', password: 'Unity2026!', phoneEnding: '3456' },
    { id: 'FESU-2026-0005', name: 'David Etim', password: 'Progress#FESU', phoneEnding: '7890' }
];

// ============================================
// UTILITY FUNCTIONS
// ============================================
const Utils = {
    generateId: () => Math.random().toString(36).substr(2, 9).toUpperCase(),
    
    generateHash: () => {
        const chars = '0123456789abcdef';
        let hash = '0x';
        for (let i = 0; i < 64; i++) {
            hash += chars[Math.floor(Math.random() * chars.length)];
        }
        return hash;
    },
    
    generateTransactionId: () => `TXN-2026-${Utils.generateId()}`,
    
    formatTimestamp: () => {
        const now = new Date();
        return now.toISOString().replace('T', ' ').substr(0, 19);
    },
    
    formatTime: (seconds) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    },
    
    maskId: (id) => {
        if (!id) return '';
        return id.substring(0, 8) + '****';
    }
};

// ============================================
// AUDIT LOG SYSTEM
// ============================================
const AuditLog = {
    add: (action, details = '') => {
        const entry = {
            timestamp: new Date().toLocaleTimeString(),
            action,
            details,
            id: Utils.generateId()
        };
        AppState.auditLog.push(entry);
        AuditLog.render();
        console.log(`[AUDIT] ${action}: ${details}`);
    },
    
    render: () => {
        const container = document.getElementById('audit-entries');
        if (!container) return;
        
        container.innerHTML = AppState.auditLog.slice(-20).map(entry => `
            <div class="audit-entry">
                <i class="fas fa-circle"></i>
                <span class="timestamp">${entry.timestamp}</span>
                <span class="message">${entry.action}${entry.details ? ` - ${entry.details}` : ''}</span>
            </div>
        `).join('');
        
        container.scrollTop = container.scrollHeight;
    }
};

// ============================================
// TOAST NOTIFICATION SYSTEM
// ============================================
const Toast = {
    show: (message, type = 'info', duration = 3000) => {
        const container = document.getElementById('toast-container');
        if (!container) return;
        
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-times-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <i class="fas ${icons[type]}"></i>
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
};

// ============================================
// SECURITY SHIELD
// ============================================
const SecurityShield = {
    init: () => {
        const steps = document.querySelectorAll('.verification-step');
        const enterBtn = document.getElementById('enter-sanctuary');
        
        // Simulate verification process
        setTimeout(() => {
            steps[0].classList.add('completed');
            steps[0].classList.remove('active');
            steps[1].classList.add('active');
            AuditLog.add('SSL Connection Established');
        }, 1000);
        
        setTimeout(() => {
            steps[1].classList.add('completed');
            steps[1].classList.remove('active');
            steps[2].classList.add('active');
            AuditLog.add('Encryption Protocols Verified');
        }, 2500);
        
        setTimeout(() => {
            enterBtn.disabled = false;
            AuditLog.add('Security Shield Verification Complete');
        }, 3500);
        
        enterBtn.addEventListener('click', SecurityShield.enter);
    },
    
    enter: () => {
        const shield = document.getElementById('security-shield');
        const app = document.getElementById('app-container');
        
        shield.classList.add('hidden');
        app.classList.remove('hidden');
        
        AuditLog.add('User Entered Sacred Sanctuary');
        SessionManager.start();
        InactivityMonitor.start();
    }
};

// ============================================
// SESSION MANAGEMENT
// ============================================
const SessionManager = {
    start: () => {
        AppState.sessionTimer = setInterval(() => {
            AppState.sessionTimeRemaining--;
            
            const countdownEl = document.getElementById('session-countdown');
            if (countdownEl) {
                countdownEl.textContent = Utils.formatTime(AppState.sessionTimeRemaining);
            }
            
            if (AppState.sessionTimeRemaining <= 0) {
                SessionManager.expire();
            }
            
            // Warning at 2 minutes
            if (AppState.sessionTimeRemaining === 120) {
                Toast.show('Your session will expire in 2 minutes. Please complete your voting.', 'warning', 5000);
            }
        }, 1000);
    },
    
    reset: () => {
        AppState.sessionTimeRemaining = 900;
    },
    
    expire: () => {
        clearInterval(AppState.sessionTimer);
        AuditLog.add('Session Expired');
        alert('Your session has expired. You will be logged out for security reasons.');
        location.reload();
    },
    
    logout: () => {
        clearInterval(AppState.sessionTimer);
        AuditLog.add('User Logged Out');
        location.reload();
    }
};

// ============================================
// INACTIVITY MONITOR
// ============================================
const InactivityMonitor = {
    INACTIVITY_LIMIT: 300000, // 5 minutes
    WARNING_TIME: 30000, // 30 seconds warning
    
    start: () => {
        const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
        events.forEach(event => {
            document.addEventListener(event, InactivityMonitor.reset, true);
        });
        
        InactivityMonitor.reset();
    },
    
    reset: () => {
        clearTimeout(AppState.inactivityTimer);
        clearTimeout(AppState.inactivityWarningTimer);
        
        // Hide warning modal if open
        const modal = document.getElementById('inactivity-modal');
        if (modal && modal.classList.contains('active')) {
            modal.classList.remove('active');
        }
        
        // Set warning timer
        AppState.inactivityWarningTimer = setTimeout(() => {
            InactivityMonitor.showWarning();
        }, InactivityMonitor.INACTIVITY_LIMIT - InactivityMonitor.WARNING_TIME);
        
        // Set logout timer
        AppState.inactivityTimer = setTimeout(() => {
            InactivityMonitor.logout();
        }, InactivityMonitor.INACTIVITY_LIMIT);
    },
    
    showWarning: () => {
        const modal = document.getElementById('inactivity-modal');
        const countdownEl = document.getElementById('inactivity-countdown');
        
        if (!modal || AppState.hasVoted) return;
        
        modal.classList.add('active');
        AppState.inactivityTimeRemaining = 30;
        
        const countdown = setInterval(() => {
            AppState.inactivityTimeRemaining--;
            if (countdownEl) {
                countdownEl.textContent = AppState.inactivityTimeRemaining;
            }
            
            if (AppState.inactivityTimeRemaining <= 0) {
                clearInterval(countdown);
            }
        }, 1000);
        
        // Auto-logout after warning
        setTimeout(() => {
            if (modal.classList.contains('active')) {
                InactivityMonitor.logout();
            }
        }, InactivityMonitor.WARNING_TIME);
    },
    
    logout: () => {
        AuditLog.add('Auto-logout due to inactivity');
        alert('You have been logged out due to inactivity.');
        location.reload();
    }
};

// ============================================
// AUTHENTICATION SYSTEM
// ============================================
const AuthSystem = {
    init: () => {
        // Membership ID verification
        document.getElementById('verify-id-btn')?.addEventListener('click', AuthSystem.verifyId);
        document.getElementById('membership-id')?.addEventListener('input', AuthSystem.formatMembershipId);
        document.getElementById('membership-id')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') AuthSystem.verifyId();
        });
        
        // Password toggle
        document.querySelector('.toggle-password')?.addEventListener('click', AuthSystem.togglePassword);
        
        // OTP inputs
        document.querySelectorAll('.otp-input').forEach((input, index) => {
            input.addEventListener('input', (e) => AuthSystem.handleOtpInput(e, index));
            input.addEventListener('keydown', (e) => AuthSystem.handleOtpKeydown(e, index));
            input.addEventListener('paste', AuthSystem.handleOtpPaste);
        });
        
        // OTP verification
        document.getElementById('verify-otp-btn')?.addEventListener('click', AuthSystem.verifyOtp);
        document.getElementById('resend-otp')?.addEventListener('click', AuthSystem.resendOtp);
        
        // Enter voting
        document.getElementById('enter-voting-btn')?.addEventListener('click', AuthSystem.enterVoting);
        
        // Logout
        document.getElementById('logout-btn')?.addEventListener('click', SessionManager.logout);
    },
    
    formatMembershipId: (e) => {
        let value = e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
        e.target.value = value;
    },
    
    togglePassword: () => {
        const input = document.getElementById('voter-password');
        const icon = document.querySelector('.toggle-password i');
        
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    },
    
    verifyId: () => {
        const idInput = document.getElementById('membership-id');
        const passwordInput = document.getElementById('voter-password');
        const id = idInput.value.trim();
        const password = passwordInput.value;
        
        // Validate format
        const idPattern = /^FESU-2026-\d{4}$/;
        if (!idPattern.test(id)) {
            Toast.show('Invalid Membership ID format. Use: FESU-2026-XXXX', 'error');
            return;
        }
        
        if (password.length < 8) {
            Toast.show('Password must be at least 8 characters', 'error');
            return;
        }
        
        // Check against valid voters
        const voter = VALID_VOTERS.find(v => v.id === id && v.password === password);
        
        if (voter) {
            AppState.voterInfo = {
                id: voter.id,
                name: voter.name,
                phoneEnding: voter.phoneEnding
            };
            
            AuditLog.add('Identity Verified', Utils.maskId(id));
            AuthSystem.proceedToStep(2);
            
            // Display phone ending
            document.getElementById('phone-ending').textContent = '****' + voter.phoneEnding;
            
            // Start OTP timer
            AuthSystem.startOtpTimer();
        } else {
            Toast.show('Invalid credentials. Please try again.', 'error');
            AuditLog.add('Failed Login Attempt', Utils.maskId(id));
        }
    },
    
    proceedToStep: (step) => {
        AppState.authStep = step;
        
        document.querySelectorAll('.auth-step').forEach((el, index) => {
            el.classList.toggle('active', index === step - 1);
        });
    },
    
    handleOtpInput: (e, index) => {
        const inputs = document.querySelectorAll('.otp-input');
        const value = e.target.value;
        
        // Only allow numbers
        if (!/^\d*$/.test(value)) {
            e.target.value = '';
            return;
        }
        
        if (value.length === 1) {
            if (index < inputs.length - 1) {
                inputs[index + 1].focus();
            }
        }
        
        AuthSystem.checkOtpComplete();
    },
    
    handleOtpKeydown: (e, index) => {
        const inputs = document.querySelectorAll('.otp-input');
        
        if (e.key === 'Backspace' && !e.target.value && index > 0) {
            inputs[index - 1].focus();
        }
    },
    
    handleOtpPaste: (e) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
        const inputs = document.querySelectorAll('.otp-input');
        
        pastedData.split('').forEach((digit, index) => {
            if (inputs[index]) {
                inputs[index].value = digit;
            }
        });
        
        AuthSystem.checkOtpComplete();
    },
    
    checkOtpComplete: () => {
        const inputs = document.querySelectorAll('.otp-input');
        const otp = Array.from(inputs).map(input => input.value).join('');
        const verifyBtn = document.getElementById('verify-otp-btn');
        
        verifyBtn.disabled = otp.length !== 6;
    },
    
    startOtpTimer: () => {
        const timerEl = document.getElementById('otp-timer');
        const resendBtn = document.getElementById('resend-otp');
        let timeLeft = 59;
        
        resendBtn.disabled = true;
        
        const timer = setInterval(() => {
            timeLeft--;
            timerEl.textContent = `Resend in ${timeLeft}s`;
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                timerEl.textContent = '';
                resendBtn.disabled = false;
            }
        }, 1000);
    },
    
    resendOtp: () => {
        Toast.show('New verification code sent!', 'success');
        AuditLog.add('OTP Resent');
        AuthSystem.startOtpTimer();
    },
    
    verifyOtp: () => {
        const inputs = document.querySelectorAll('.otp-input');
        const otp = Array.from(inputs).map(input => input.value).join('');
        
        // Mock OTP verification (any 6 digits for demo)
        if (otp.length === 6) {
            AuditLog.add('Two-Factor Authentication Successful');
            AuthSystem.proceedToStep(3);
            
            // Update profile info
            document.getElementById('voter-name').textContent = `Welcome, ${AppState.voterInfo.name}`;
            document.getElementById('voter-id-display').textContent = `ID: ${AppState.voterInfo.id}`;
            
            AppState.isAuthenticated = true;
        } else {
            Toast.show('Invalid verification code', 'error');
        }
    },
    
    enterVoting: () => {
        SectionManager.show('voting-section');
        AuditLog.add('Entered Voting Booth');
    }
};

// ============================================
// SECTION MANAGEMENT
// ============================================
const SectionManager = {
    show: (sectionId) => {
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            AppState.currentSection = sectionId;
        }
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
};

// ============================================
// VOTING SYSTEM
// ============================================
const VotingSystem = {
    init: () => {
        // Candidate selection
        document.querySelectorAll('.candidate-card').forEach(card => {
            card.addEventListener('click', () => VotingSystem.selectCandidate(card));
        });
        
        // Review button
        document.getElementById('review-votes-btn')?.addEventListener('click', VotingSystem.showReview);
        
        // Back to voting
        document.getElementById('back-to-voting-btn')?.addEventListener('click', () => {
            SectionManager.show('voting-section');
            AuditLog.add('Returned to Voting Booth');
        });
        
        // Submit vote
        document.getElementById('submit-vote-btn')?.addEventListener('click', VotingSystem.showConfirmation);
        
        // Modal buttons
        document.getElementById('modal-cancel-btn')?.addEventListener('click', VotingSystem.hideConfirmation);
        document.getElementById('modal-confirm-btn')?.addEventListener('click', VotingSystem.submitVote);
        
        // Confirmation checkboxes
        document.querySelectorAll('.confirmation-checklist input').forEach(checkbox => {
            checkbox.addEventListener('change', VotingSystem.checkConfirmations);
        });
        
        // Success actions
        document.getElementById('download-receipt-btn')?.addEventListener('click', VotingSystem.downloadReceipt);
        document.getElementById('finish-voting-btn')?.addEventListener('click', SessionManager.logout);
        
        // Copy buttons
        document.querySelectorAll('.copy-btn').forEach(btn => {
            btn.addEventListener('click', VotingSystem.copyToClipboard);
        });
    },
    
    selectCandidate: (card) => {
        const positionCard = card.closest('.position-card');
        const position = positionCard.dataset.position;
        const candidate = card.dataset.candidate;
        
        // Remove selection from other candidates in same position
        positionCard.querySelectorAll('.candidate-card').forEach(c => {
            c.classList.remove('selected');
        });
        
        // Select clicked candidate
        card.classList.add('selected');
        
        // Update state
        AppState.selections[position] = candidate;
        
        // Update position status
        const statusIcon = positionCard.querySelector('.position-status');
        statusIcon.dataset.status = 'completed';
        statusIcon.innerHTML = '<i class="fas fa-check-circle"></i>';
        positionCard.classList.add('completed');
        
        AuditLog.add('Candidate Selected', `${position}: ${candidate}`);
        
        VotingSystem.updateProgress();
    },
    
    updateProgress: () => {
        const totalPositions = 8;
        const completedPositions = Object.keys(AppState.selections).length;
        const percentage = (completedPositions / totalPositions) * 100;
        
        document.getElementById('positions-completed').textContent = completedPositions;
        document.getElementById('progress-fill').style.width = `${percentage}%`;
        
        const reviewBtn = document.getElementById('review-votes-btn');
        reviewBtn.disabled = completedPositions < totalPositions;
    },
    
    showReview: () => {
        // Populate review summary
        Object.keys(CANDIDATES).forEach(position => {
            const selectedCandidate = AppState.selections[position];
            const reviewEl = document.getElementById(`review-${position}`);
            
            if (selectedCandidate && CANDIDATES[position][selectedCandidate]) {
                const candidate = CANDIDATES[position][selectedCandidate];
                reviewEl.textContent = candidate.name;
                reviewEl.classList.remove('not-selected');
            } else {
                reviewEl.textContent = 'Not Selected';
                reviewEl.classList.add('not-selected');
            }
        });
        
        SectionManager.show('review-section');
        AuditLog.add('Reviewed Vote Selections');
    },
    
    showConfirmation: () => {
        const modal = document.getElementById('confirmation-modal');
        modal.classList.add('active');
        AuditLog.add('Opened Final Confirmation');
    },
    
    hideConfirmation: () => {
        const modal = document.getElementById('confirmation-modal');
        modal.classList.remove('active');
        
        // Reset checkboxes
        document.querySelectorAll('.confirmation-checklist input').forEach(cb => {
            cb.checked = false;
        });
        document.getElementById('modal-confirm-btn').disabled = true;
    },
    
    checkConfirmations: () => {
        const checkboxes = document.querySelectorAll('.confirmation-checklist input');
        const allChecked = Array.from(checkboxes).every(cb => cb.checked);
        document.getElementById('modal-confirm-btn').disabled = !allChecked;
    },
    
    submitVote: () => {
        VotingSystem.hideConfirmation();
        
        // Generate receipt data
        const receiptData = {
            transactionId: Utils.generateTransactionId(),
            timestamp: Utils.formatTimestamp(),
            voterHash: Utils.generateHash(),
            blockchainHash: Utils.generateHash()
        };
        
        // Update receipt display
        document.getElementById('receipt-tx-id').textContent = receiptData.transactionId;
        document.getElementById('receipt-timestamp').textContent = receiptData.timestamp;
        document.getElementById('receipt-voter-hash').textContent = receiptData.voterHash.substring(0, 20) + '...';
        document.getElementById('receipt-blockchain-hash').textContent = receiptData.blockchainHash.substring(0, 20) + '...';
        
        // Store full hashes for download
        AppState.receiptData = receiptData;
        
        AppState.hasVoted = true;
        AuditLog.add('Vote Submitted Successfully', receiptData.transactionId);
        
        SectionManager.show('success-section');
        
        // Prevent back button
        VotingSystem.preventBackButton();
    },
    
    preventBackButton: () => {
        history.pushState(null, null, location.href);
        window.onpopstate = () => {
            history.pushState(null, null, location.href);
            Toast.show('You cannot go back after voting. Please logout.', 'warning');
        };
    },
    
    copyToClipboard: (e) => {
        const btn = e.currentTarget;
        const copyType = btn.dataset.copy;
        let textToCopy = '';
        
        switch(copyType) {
            case 'tx-id':
                textToCopy = AppState.receiptData?.transactionId || '';
                break;
            case 'voter-hash':
                textToCopy = AppState.receiptData?.voterHash || '';
                break;
            case 'blockchain-hash':
                textToCopy = AppState.receiptData?.blockchainHash || '';
                break;
        }
        
        if (textToCopy) {
            navigator.clipboard.writeText(textToCopy).then(() => {
                Toast.show('Copied to clipboard!', 'success');
            }).catch(() => {
                Toast.show('Failed to copy', 'error');
            });
        }
    },
    
    downloadReceipt: () => {
        const receiptContent = `
FESU-WW 2026 ELECTION - VOTING RECEIPT
======================================

Transaction ID: ${AppState.receiptData.transactionId}
Timestamp: ${AppState.receiptData.timestamp}
Voter Hash: ${AppState.receiptData.voterHash}
Blockchain Hash: ${AppState.receiptData.blockchainHash}

VOTER SELECTIONS:
-----------------
Spirit Head (President): ${VotingSystem.getCandidateName('spirit-head')}
Deputy Spirit Head (Vice President): ${VotingSystem.getCandidateName('deputy-spirit-head')}
Scribe General (General Secretary): ${VotingSystem.getCandidateName('scribe-general')}
Keeper of Treasury (Financial Secretary): ${VotingSystem.getCandidateName('keeper-treasury')}
Director of Socials: ${VotingSystem.getCandidateName('director-socials')}
Director of Sports: ${VotingSystem.getCandidateName('director-sports')}
Director of Welfare: ${VotingSystem.getCandidateName('director-welfare')}
Provost (Chief Whip): ${VotingSystem.getCandidateName('provost')}

======================================
This receipt serves as proof of your vote.
Keep this receipt secure and confidential.

FESU-WW Election Commission
Date: March 28, 2026
        `;
        
        const blob = new Blob([receiptContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `FESU-WW-Receipt-${AppState.receiptData.transactionId}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        AuditLog.add('Receipt Downloaded');
        Toast.show('Receipt downloaded successfully!', 'success');
    },
    
    getCandidateName: (position) => {
        const candidateId = AppState.selections[position];
        if (candidateId && CANDIDATES[position][candidateId]) {
            return CANDIDATES[position][candidateId].name;
        }
        return 'Not Selected';
    }
};

// ============================================
// AUDIT PANEL TOGGLE
// ============================================
const AuditPanel = {
    init: () => {
        const toggle = document.getElementById('audit-toggle');
        const content = document.getElementById('audit-content');
        
        toggle?.addEventListener('click', () => {
            content.classList.toggle('open');
            const icon = toggle.querySelector('i');
            icon.classList.toggle('fa-chevron-down');
            icon.classList.toggle('fa-chevron-up');
        });
    }
};

// ============================================
// INACTIVITY MODAL
// ============================================
const InactivityModal = {
    init: () => {
        document.getElementById('inactivity-continue-btn')?.addEventListener('click', () => {
            document.getElementById('inactivity-modal').classList.remove('active');
            InactivityMonitor.reset();
        });
        
        document.getElementById('inactivity-logout-btn')?.addEventListener('click', SessionManager.logout);
    }
};

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    // Initialize all systems
    SecurityShield.init();
    AuthSystem.init();
    VotingSystem.init();
    AuditPanel.init();
    InactivityModal.init();
    
    // Add initial audit entry
    AuditLog.add('Election Portal Loaded');
    
    console.log('%c🔒 FESU-WW 2026 Election Portal', 'color: #D4AF37; font-size: 20px; font-weight: bold;');
    console.log('%cSacred Election Sanctuary - Secure Voting System', 'color: #8B0000; font-size: 14px;');
});

// Handle page unload
window.addEventListener('beforeunload', (e) => {
    if (AppState.isAuthenticated && !AppState.hasVoted) {
        e.preventDefault();
        e.returnValue = 'You have not completed your vote. Are you sure you want to leave?';
    }
});

// Prevent right-click context menu in voting section
document.addEventListener('contextmenu', (e) => {
    if (AppState.currentSection === 'voting-section' || AppState.currentSection === 'review-section') {
        e.preventDefault();
        Toast.show('Right-click is disabled for security reasons', 'warning');
    }
});

// Prevent keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Prevent F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
    if (
        e.key === 'F12' ||
        (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J')) ||
        (e.ctrlKey && e.key === 'U')
    ) {
        e.preventDefault();
        Toast.show('Developer tools are disabled for security reasons', 'warning');
    }
});
