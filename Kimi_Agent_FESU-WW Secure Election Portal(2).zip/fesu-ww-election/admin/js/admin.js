/**
 * FESU-WW 2026 Election - Electoral Board Admin Dashboard
 * JavaScript for real-time monitoring, data visualization, and admin functionality
 */

// ========================================
// GLOBAL STATE
// ========================================
const AppState = {
    isLoggedIn: false,
    currentUser: null,
    currentRole: null,
    activeSection: 'overview',
    registeredVoters: 2847,
    votesCast: 1924,
    electionDate: new Date('2026-03-28T18:00:00'),
    charts: {},
    updateInterval: null,
    voters: [],
    auditLog: [],
    sessions: [],
    results: {}
};

// ========================================
// MOCK DATA
// ========================================

// Election Results Data
const electionResults = {
    'spirit-head': {
        title: 'Spirit Head',
        candidates: [
            { name: 'John Okon', votes: 523, color: '#D4AF37' },
            { name: 'Mary Etim', votes: 412, color: '#58a6ff' },
            { name: 'Peter Akpan', votes: 298, color: '#f0883e' }
        ]
    },
    'deputy-spirit-head': {
        title: 'Deputy Spirit Head',
        candidates: [
            { name: 'Sarah Bassey', votes: 456, color: '#D4AF37' },
            { name: 'David Essien', votes: 389, color: '#58a6ff' }
        ]
    },
    'scribe-general': {
        title: 'Scribe General',
        candidates: [
            { name: 'Grace Udo', votes: 512, color: '#D4AF37' },
            { name: 'James Obot', votes: 367, color: '#58a6ff' },
            { name: 'Rose Emmanuel', votes: 234, color: '#f0883e' }
        ]
    },
    'keeper-treasury': {
        title: 'Keeper of Treasury',
        candidates: [
            { name: 'Michael Edet', votes: 478, color: '#D4AF37' },
            { name: 'Helen Udoh', votes: 445, color: '#58a6ff' }
        ]
    },
    'director-socials': {
        title: 'Director of Socials',
        candidates: [
            { name: 'Victor Inyang', votes: 398, color: '#D4AF37' },
            { name: 'Linda Archibong', votes: 356, color: '#58a6ff' },
            { name: 'Samuel Udo', votes: 267, color: '#f0883e' }
        ]
    },
    'director-sports': {
        title: 'Director of Sports',
        candidates: [
            { name: 'Daniel Ekanem', votes: 467, color: '#D4AF37' },
            { name: 'Patience Obong', votes: 312, color: '#58a6ff' }
        ]
    },
    'director-welfare': {
        title: 'Director of Welfare',
        candidates: [
            { name: 'Esther Ukpong', votes: 423, color: '#D4AF37' },
            { name: 'Joseph Akpan', votes: 398, color: '#58a6ff' },
            { name: 'Blessing Eyo', votes: 189, color: '#f0883e' }
        ]
    },
    'provost': {
        title: 'Provost',
        candidates: [
            { name: 'Matthew Okon', votes: 445, color: '#D4AF37' },
            { name: 'Faith Solomon', votes: 412, color: '#58a6ff' }
        ]
    }
};

// Generate Mock Voters
function generateVoters() {
    const firstNames = ['John', 'Mary', 'Peter', 'Sarah', 'David', 'Grace', 'James', 'Rose', 'Michael', 'Helen', 'Victor', 'Linda', 'Samuel', 'Daniel', 'Patience', 'Esther', 'Joseph', 'Blessing', 'Matthew', 'Faith', 'Emmanuel', 'Ruth', 'Paul', 'Deborah', 'Simon', 'Martha', 'Thomas', 'Abigail', 'Andrew', 'Rebecca'];
    const lastNames = ['Okon', 'Etim', 'Akpan', 'Bassey', 'Essien', 'Udo', 'Obot', 'Emmanuel', 'Edet', 'Udoh', 'Inyang', 'Archibong', 'Udo', 'Ekanem', 'Obong', 'Ukpong', 'Akpan', 'Eyo', 'Okon', 'Solomon', 'Effiong', 'Eyo', 'Archibong', 'Inyang', 'Udoh', 'Edet', 'Obot', 'Udo', 'Essien', 'Bassey'];
    const departments = ['Computer Science', 'Business Administration', 'Mass Communication', 'Political Science', 'Economics', 'Accounting', 'Law', 'Medicine', 'Engineering', 'Education'];
    const statuses = ['verified', 'verified', 'verified', 'verified', 'pending', 'flagged', 'suspended'];
    
    const voters = [];
    for (let i = 1; i <= 150; i++) {
        const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const hasVoted = status === 'verified' && Math.random() > 0.3;
        
        voters.push({
            id: `FESU${String(i).padStart(4, '0')}`,
            name: `${firstName} ${lastName}`,
            email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@fesu-ww.org`,
            department: departments[Math.floor(Math.random() * departments.length)],
            status: status,
            voted: hasVoted,
            registrationDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
        });
    }
    return voters;
}

// Generate Mock Audit Log
function generateAuditLog() {
    const events = [
        { type: 'login', title: 'Admin Login', icon: 'sign-in-alt', class: 'info' },
        { type: 'vote', title: 'Vote Cast', icon: 'vote-yea', class: 'success' },
        { type: 'system', title: 'System Backup', icon: 'hdd', class: 'info' },
        { type: 'security', title: 'Failed Login Attempt', icon: 'exclamation-triangle', class: 'danger' },
        { type: 'login', title: 'Voter Login', icon: 'user', class: 'success' }
    ];
    
    const log = [];
    const actions = [
        'Successful login from IP 192.168.1.105',
        'Vote recorded for Spirit Head position',
        'Automated backup completed successfully',
        'Multiple failed login attempts detected',
        'New voter registration approved',
        'Password reset requested',
        'Two-factor authentication enabled'
    ];
    
    for (let i = 0; i < 50; i++) {
        const event = events[Math.floor(Math.random() * events.length)];
        const timeAgo = Math.floor(Math.random() * 1440); // minutes ago
        
        log.push({
            type: event.type,
            title: event.title,
            description: actions[Math.floor(Math.random() * actions.length)],
            user: `User${Math.floor(Math.random() * 100) + 1}`,
            ip: `192.168.1.${Math.floor(Math.random() * 255)}`,
            time: timeAgo,
            icon: event.icon,
            class: event.class
        });
    }
    
    return log.sort((a, b) => a.time - b.time);
}

// Generate Mock Sessions
function generateSessions() {
    return [
        { user: 'Electoral Chairman', role: 'Admin', device: 'Chrome / Windows', location: 'Lagos, Nigeria', time: '2 mins ago' },
        { user: 'Electoral Secretary', role: 'Admin', device: 'Firefox / MacOS', location: 'Abuja, Nigeria', time: '15 mins ago' },
        { user: 'Board Member 1', role: 'Board', device: 'Safari / iOS', location: 'Port Harcourt, Nigeria', time: '32 mins ago' },
        { user: 'Board Member 2', role: 'Board', device: 'Chrome / Android', location: 'Uyo, Nigeria', time: '1 hour ago' },
        { user: 'Voter #2847', role: 'Voter', device: 'Chrome / Windows', location: 'Calabar, Nigeria', time: 'Just now' }
    ];
}

// Generate Suspicious Alerts
function generateSuspiciousAlerts() {
    return [
        { title: 'Multiple Failed Logins', description: 'IP 192.168.1.245 attempted 5 failed logins in 2 minutes', time: '5 mins ago', severity: 'high' },
        { title: 'Unusual Voting Pattern', description: 'Multiple votes from same network within 30 seconds', time: '12 mins ago', severity: 'medium' },
        { title: 'Account Lockout', description: 'Account FESU0892 locked due to multiple failed attempts', time: '28 mins ago', severity: 'low' },
        { title: 'Geographic Anomaly', description: 'Login from unusual location for user FESU1234', time: '45 mins ago', severity: 'medium' }
    ];
}

// ========================================
// INITIALIZATION
// ========================================
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize mock data
    AppState.voters = generateVoters();
    AppState.auditLog = generateAuditLog();
    AppState.sessions = generateSessions();
    AppState.suspiciousAlerts = generateSuspiciousAlerts();
    
    // Setup event listeners
    setupLoginHandlers();
    setupNavigation();
    setupVoterSearch();
    setupAuditFilters();
    setupOTPInputs();
    
    // Start countdown timer
    updateCountdown();
    setInterval(updateCountdown, 1000);
    
    // Initialize charts
    setTimeout(() => {
        initLiveVoteChart();
        initResultCharts();
        initSecurityCharts();
    }, 100);
}

// ========================================
// LOGIN HANDLERS
// ========================================
function setupLoginHandlers() {
    const loginForm = document.getElementById('loginForm');
    const verify2FA = document.getElementById('verify2FA');
    const backToLogin = document.getElementById('backToLogin');
    const togglePassword = document.querySelector('.toggle-password');
    
    // Toggle password visibility
    togglePassword?.addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
    
    // Login form submission
    loginForm?.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const role = document.getElementById('role').value;
        
        if (username && role) {
            AppState.currentUser = username;
            AppState.currentRole = role;
            
            // Show 2FA step
            document.getElementById('loginStep1').classList.remove('active');
            document.getElementById('loginStep2').classList.add('active');
            
            // Focus first OTP input
            document.querySelector('.otp-digit')?.focus();
            
            showNotification('2FA code sent to your device');
        }
    });
    
    // 2FA verification
    verify2FA?.addEventListener('click', function() {
        const otpDigits = document.querySelectorAll('.otp-digit');
        let otp = '';
        otpDigits.forEach(digit => otp += digit.value);
        
        if (otp.length === 6) {
            // Simulate 2FA verification
            completeLogin();
        } else {
            showNotification('Please enter complete 6-digit code', 'error');
        }
    });
    
    // Back to login
    backToLogin?.addEventListener('click', function() {
        document.getElementById('loginStep2').classList.remove('active');
        document.getElementById('loginStep1').classList.add('active');
        
        // Clear OTP inputs
        document.querySelectorAll('.otp-digit').forEach(input => input.value = '');
    });
    
    // Resend code
    document.getElementById('resendCode')?.addEventListener('click', function(e) {
        e.preventDefault();
        showNotification('New 2FA code sent');
    });
    
    // Logout
    document.getElementById('logoutBtn')?.addEventListener('click', function() {
        AppState.isLoggedIn = false;
        AppState.currentUser = null;
        AppState.currentRole = null;
        
        document.getElementById('mainDashboard').classList.add('hidden');
        document.getElementById('loginOverlay').classList.remove('hidden');
        
        // Clear form
        document.getElementById('loginForm').reset();
        document.querySelectorAll('.otp-digit').forEach(input => input.value = '');
        document.getElementById('loginStep2').classList.remove('active');
        document.getElementById('loginStep1').classList.add('active');
        
        showNotification('Logged out successfully');
    });
}

function setupOTPInputs() {
    const otpInputs = document.querySelectorAll('.otp-digit');
    
    otpInputs.forEach((input, index) => {
        input.addEventListener('input', function() {
            if (this.value.length === 1) {
                if (index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
            }
        });
        
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && this.value === '' && index > 0) {
                otpInputs[index - 1].focus();
            }
        });
        
        input.addEventListener('paste', function(e) {
            e.preventDefault();
            const pastedData = e.clipboardData.getData('text').slice(0, 6);
            
            otpInputs.forEach((inp, i) => {
                if (pastedData[i]) {
                    inp.value = pastedData[i];
                }
            });
            
            if (pastedData.length === 6) {
                document.getElementById('verify2FA').focus();
            } else if (pastedData.length < 6) {
                otpInputs[pastedData.length]?.focus();
            }
        });
    });
}

function completeLogin() {
    AppState.isLoggedIn = true;
    
    // Update admin info
    const roleDisplay = {
        'chairman': 'Electoral Chairman',
        'secretary': 'Electoral Secretary',
        'board': 'Board Member'
    };
    
    document.getElementById('adminName').textContent = AppState.currentUser;
    document.getElementById('adminRole').textContent = roleDisplay[AppState.currentRole] || 'Admin';
    
    // Show dashboard
    document.getElementById('loginOverlay').classList.add('hidden');
    document.getElementById('mainDashboard').classList.remove('hidden');
    
    // Initialize dashboard data
    updateDashboardStats();
    renderRecentActivity();
    renderVotersTable();
    renderAuditLog();
    renderSessions();
    renderSuspiciousAlerts();
    renderSecurityAlerts();
    
    // Start real-time updates
    startRealTimeUpdates();
    
    showNotification('Login successful! Welcome to FESU-WW Electoral Dashboard');
}

// ========================================
// NAVIGATION
// ========================================
function setupNavigation() {
    const navLinks = document.querySelectorAll('.sidebar-nav a');
    const sections = document.querySelectorAll('.content-section');
    const pageTitle = document.getElementById('pageTitle');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetSection = this.getAttribute('data-section');
            
            // Update active nav
            navLinks.forEach(l => l.parentElement.classList.remove('active'));
            this.parentElement.classList.add('active');
            
            // Show target section
            sections.forEach(section => section.classList.remove('active'));
            document.getElementById(targetSection + 'Section').classList.add('active');
            
            // Update page title
            const titles = {
                'overview': 'Dashboard Overview',
                'results': 'Election Results',
                'voters': 'Voter Management',
                'audit': 'Audit & Monitoring',
                'security': 'Security Panel'
            };
            pageTitle.textContent = titles[targetSection];
            
            AppState.activeSection = targetSection;
        });
    });
    
    // Sidebar toggle
    document.getElementById('sidebarToggle')?.addEventListener('click', function() {
        document.querySelector('.sidebar').classList.toggle('collapsed');
    });
}

// ========================================
// DASHBOARD STATS
// ========================================
function updateDashboardStats() {
    const voterTurnout = ((AppState.votesCast / AppState.registeredVoters) * 100).toFixed(1);
    
    // Animate numbers
    animateNumber('registeredVoters', AppState.registeredVoters);
    animateNumber('votesCast', AppState.votesCast);
    
    document.getElementById('voterTurnout').textContent = voterTurnout + '%';
    document.getElementById('turnoutProgress').style.width = voterTurnout + '%';
    document.getElementById('voterGrowth').textContent = '+' + (Math.random() * 5 + 1).toFixed(1) + '%';
}

function animateNumber(elementId, targetValue) {
    const element = document.getElementById(elementId);
    const duration = 1000;
    const startValue = 0;
    const startTime = performance.now();
    
    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easeProgress = 1 - Math.pow(1 - progress, 3);
        const currentValue = Math.floor(startValue + (targetValue - startValue) * easeProgress);
        
        element.textContent = currentValue.toLocaleString();
        
        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }
    
    requestAnimationFrame(update);
}

function updateCountdown() {
    const now = new Date();
    const diff = AppState.electionDate - now;
    
    if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        
        document.getElementById('timeRemaining').textContent = 
            `${days}d ${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;
        document.getElementById('countdown').textContent = 
            `${days}d ${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m`;
    } else {
        document.getElementById('timeRemaining').textContent = 'Polls Closed';
        document.getElementById('countdown').textContent = 'Closed';
    }
}

// ========================================
// REAL-TIME UPDATES
// ========================================
function startRealTimeUpdates() {
    // Update every 30 seconds
    AppState.updateInterval = setInterval(() => {
        // Simulate vote updates
        const newVotes = Math.floor(Math.random() * 5) + 1;
        AppState.votesCast += newVotes;
        
        // Update stats
        updateDashboardStats();
        
        // Update live chart
        updateLiveVoteChart();
        
        // Update results
        updateResults();
        
        // Add new activity
        addNewActivity();
        
    }, 30000); // 30 seconds
}

function addNewActivity() {
    const activities = [
        { title: 'New vote cast', type: 'vote', icon: 'vote-yea' },
        { title: 'Voter logged in', type: 'login', icon: 'sign-in-alt' },
        { title: 'New registration', type: 'system', icon: 'user-plus' }
    ];
    
    const activity = activities[Math.floor(Math.random() * activities.length)];
    const activityList = document.getElementById('recentActivityList');
    
    const newItem = document.createElement('div');
    newItem.className = 'activity-item';
    newItem.innerHTML = `
        <div class="activity-icon ${activity.type}">
            <i class="fas fa-${activity.icon}"></i>
        </div>
        <div class="activity-content">
            <div class="activity-title">${activity.title}</div>
            <div class="activity-meta">
                <span><i class="fas fa-clock"></i> Just now</span>
                <span><i class="fas fa-user"></i> Voter #${Math.floor(Math.random() * 2847) + 1}</span>
            </div>
        </div>
    `;
    
    activityList.insertBefore(newItem, activityList.firstChild);
    
    // Keep only last 5 items
    while (activityList.children.length > 5) {
        activityList.removeChild(activityList.lastChild);
    }
}

// ========================================
// CHARTS
// ========================================
function initLiveVoteChart() {
    const ctx = document.getElementById('liveVoteChart');
    if (!ctx) return;
    
    const labels = Array.from({length: 12}, (_, i) => `${i * 5}m ago`).reverse();
    const data = Array.from({length: 12}, () => Math.floor(Math.random() * 20) + 10);
    
    AppState.charts.liveVote = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Votes per 5 minutes',
                data: data,
                borderColor: '#D4AF37',
                backgroundColor: 'rgba(212, 175, 55, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#D4AF37',
                pointBorderColor: '#fff',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    },
                    ticks: {
                        color: '#8b949e'
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    },
                    ticks: {
                        color: '#8b949e'
                    }
                }
            }
        }
    });
}

function updateLiveVoteChart() {
    if (!AppState.charts.liveVote) return;
    
    const chart = AppState.charts.liveVote;
    const newData = Math.floor(Math.random() * 20) + 10;
    
    chart.data.datasets[0].data.shift();
    chart.data.datasets[0].data.push(newData);
    chart.update('none');
}

function initResultCharts() {
    Object.keys(electionResults).forEach(position => {
        const canvas = document.getElementById(position + 'Chart');
        if (!canvas) return;
        
        const result = electionResults[position];
        const totalVotes = result.candidates.reduce((sum, c) => sum + c.votes, 0);
        
        // Render candidates list
        const candidatesList = document.getElementById(position.replace(/-/g, '') + 'Candidates');
        if (candidatesList) {
            candidatesList.innerHTML = result.candidates.map((candidate, index) => {
                const percentage = ((candidate.votes / totalVotes) * 100).toFixed(1);
                const isLeading = index === 0;
                
                return `
                    <div class="candidate-item ${isLeading ? 'leading' : ''}">
                        <div class="candidate-rank">${index + 1}</div>
                        <div class="candidate-avatar">${candidate.name.split(' ').map(n => n[0]).join('')}</div>
                        <div class="candidate-info">
                            <div class="candidate-name">${candidate.name}</div>
                            <div class="candidate-votes">${candidate.votes.toLocaleString()} votes</div>
                        </div>
                        <div class="candidate-percentage">
                            <div class="percentage">${percentage}%</div>
                            <div class="vote-bar">
                                <div class="vote-bar-fill" style="width: ${percentage}%"></div>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }
        
        // Update total votes
        const totalElement = document.getElementById(position.replace(/-/g, '') + 'Total');
        if (totalElement) {
            totalElement.textContent = totalVotes.toLocaleString();
        }
        
        // Create chart
        AppState.charts[position] = new Chart(canvas, {
            type: 'doughnut',
            data: {
                labels: result.candidates.map(c => c.name),
                datasets: [{
                    data: result.candidates.map(c => c.votes),
                    backgroundColor: result.candidates.map(c => c.color),
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                cutout: '70%'
            }
        });
    });
}

function updateResults() {
    // Simulate random vote updates
    Object.keys(electionResults).forEach(position => {
        if (Math.random() > 0.7) {
            const result = electionResults[position];
            const randomCandidate = result.candidates[Math.floor(Math.random() * result.candidates.length)];
            randomCandidate.votes += Math.floor(Math.random() * 3) + 1;
            
            // Re-render candidates list
            const candidatesList = document.getElementById(position.replace(/-/g, '') + 'Candidates');
            if (candidatesList) {
                const totalVotes = result.candidates.reduce((sum, c) => sum + c.votes, 0);
                
                // Sort by votes
                const sortedCandidates = [...result.candidates].sort((a, b) => b.votes - a.votes);
                
                candidatesList.innerHTML = sortedCandidates.map((candidate, index) => {
                    const percentage = ((candidate.votes / totalVotes) * 100).toFixed(1);
                    const isLeading = index === 0;
                    
                    return `
                        <div class="candidate-item ${isLeading ? 'leading' : ''}">
                            <div class="candidate-rank">${index + 1}</div>
                            <div class="candidate-avatar">${candidate.name.split(' ').map(n => n[0]).join('')}</div>
                            <div class="candidate-info">
                                <div class="candidate-name">${candidate.name}</div>
                                <div class="candidate-votes">${candidate.votes.toLocaleString()} votes</div>
                            </div>
                            <div class="candidate-percentage">
                                <div class="percentage">${percentage}%</div>
                                <div class="vote-bar">
                                    <div class="vote-bar-fill" style="width: ${percentage}%"></div>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
                
                // Update chart
                if (AppState.charts[position]) {
                    AppState.charts[position].data.datasets[0].data = sortedCandidates.map(c => c.votes);
                    AppState.charts[position].update('none');
                }
                
                // Update total
                const totalElement = document.getElementById(position.replace(/-/g, '') + 'Total');
                if (totalElement) {
                    totalElement.textContent = totalVotes.toLocaleString();
                }
            }
        }
    });
}

function initSecurityCharts() {
    // Failed logins chart
    const failedLoginsCtx = document.getElementById('failedLoginsChart');
    if (failedLoginsCtx) {
        AppState.charts.failedLogins = new Chart(failedLoginsCtx, {
            type: 'bar',
            data: {
                labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
                datasets: [{
                    label: 'Failed Attempts',
                    data: [2, 1, 5, 3, 8, 4],
                    backgroundColor: 'rgba(218, 54, 51, 0.7)',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#8b949e' }
                    },
                    y: {
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#8b949e' }
                    }
                }
            }
        });
    }
    
    // Traffic chart
    const trafficCtx = document.getElementById('trafficChart');
    if (trafficCtx) {
        AppState.charts.traffic = new Chart(trafficCtx, {
            type: 'pie',
            data: {
                labels: ['Nigeria', 'Ghana', 'UK', 'USA', 'Others'],
                datasets: [{
                    data: [85, 5, 4, 3, 3],
                    backgroundColor: ['#D4AF37', '#58a6ff', '#f0883e', '#238636', '#6e7681']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: { color: '#8b949e' }
                    }
                }
            }
        });
    }
    
    // IP Reputation List
    const ipList = document.getElementById('ipReputationList');
    if (ipList) {
        const ipData = [
            { ip: '192.168.1.105', country: 'Nigeria', reputation: 'safe' },
            { ip: '192.168.1.245', country: 'Nigeria', reputation: 'suspicious' },
            { ip: '10.0.0.56', country: 'Ghana', reputation: 'safe' },
            { ip: '172.16.0.12', country: 'UK', reputation: 'safe' },
            { ip: '203.0.113.45', country: 'Unknown', reputation: 'blocked' }
        ];
        
        ipList.innerHTML = ipData.map(item => `
            <div class="ip-item">
                <div>
                    <div class="ip-address">${item.ip}</div>
                    <div class="ip-country">${item.country}</div>
                </div>
                <span class="ip-reputation ${item.reputation}">${item.reputation}</span>
            </div>
        `).join('');
    }
}

// ========================================
// RECENT ACTIVITY
// ========================================
function renderRecentActivity() {
    const activityList = document.getElementById('recentActivityList');
    if (!activityList) return;
    
    const activities = [
        { title: 'New vote cast for Spirit Head', type: 'vote', time: '2 mins ago', user: 'Voter #1924' },
        { title: 'Admin login successful', type: 'login', time: '5 mins ago', user: 'Electoral Chairman' },
        { title: 'System backup completed', type: 'system', time: '15 mins ago', user: 'System' },
        { title: 'Failed login attempt', type: 'alert', time: '18 mins ago', user: 'Unknown' },
        { title: 'New voter registration', type: 'vote', time: '32 mins ago', user: 'Voter #2847' }
    ];
    
    activityList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon ${activity.type}">
                <i class="fas fa-${activity.type === 'vote' ? 'vote-yea' : activity.type === 'login' ? 'sign-in-alt' : activity.type === 'alert' ? 'exclamation-triangle' : 'hdd'}"></i>
            </div>
            <div class="activity-content">
                <div class="activity-title">${activity.title}</div>
                <div class="activity-meta">
                    <span><i class="fas fa-clock"></i> ${activity.time}</span>
                    <span><i class="fas fa-user"></i> ${activity.user}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// ========================================
// VOTER MANAGEMENT
// ========================================
let currentPage = 1;
const votersPerPage = 10;
let filteredVoters = [];

function renderVotersTable() {
    filteredVoters = [...AppState.voters];
    updateVoterStats();
    displayVotersPage(1);
}

function updateVoterStats() {
    const total = AppState.voters.length;
    const verified = AppState.voters.filter(v => v.status === 'verified').length;
    const pending = AppState.voters.filter(v => v.status === 'pending').length;
    const flagged = AppState.voters.filter(v => v.status === 'flagged').length;
    const voted = AppState.voters.filter(v => v.voted).length;
    
    document.getElementById('totalVotersCount').textContent = total;
    document.getElementById('verifiedCount').textContent = verified;
    document.getElementById('pendingCount').textContent = pending;
    document.getElementById('flaggedCount').textContent = flagged;
    document.getElementById('votedCount').textContent = voted;
}

function displayVotersPage(page) {
    currentPage = page;
    const start = (page - 1) * votersPerPage;
    const end = start + votersPerPage;
    const pageVoters = filteredVoters.slice(start, end);
    
    const tbody = document.getElementById('votersTableBody');
    tbody.innerHTML = pageVoters.map(voter => `
        <tr>
            <td><input type="checkbox"></td>
            <td>${voter.id}</td>
            <td>${voter.name}</td>
            <td>${voter.email}</td>
            <td>${voter.department}</td>
            <td><span class="status-badge-table ${voter.status}">${voter.status}</span></td>
            <td><i class="fas fa-${voter.voted ? 'check-circle voted-yes' : 'times-circle voted-no'}"></i></td>
            <td>${voter.registrationDate}</td>
            <td>
                <div class="action-btns">
                    <button class="action-btn" onclick="viewVoter('${voter.id}')" title="View">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn" onclick="editVoter('${voter.id}')" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn" onclick="flagVoter('${voter.id}')" title="Flag">
                        <i class="fas fa-flag"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
    
    // Update pagination
    const totalPages = Math.ceil(filteredVoters.length / votersPerPage);
    document.getElementById('currentPage').textContent = page;
    document.getElementById('totalPages').textContent = totalPages || 1;
    document.getElementById('prevPage').disabled = page === 1;
    document.getElementById('nextPage').disabled = page >= totalPages;
}

function setupVoterSearch() {
    const searchInput = document.getElementById('voterSearch');
    const statusFilter = document.getElementById('statusFilter');
    const votedFilter = document.getElementById('votedFilter');
    
    const filterVoters = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const status = statusFilter.value;
        const voted = votedFilter.value;
        
        filteredVoters = AppState.voters.filter(voter => {
            const matchesSearch = voter.name.toLowerCase().includes(searchTerm) ||
                                  voter.id.toLowerCase().includes(searchTerm) ||
                                  voter.email.toLowerCase().includes(searchTerm);
            const matchesStatus = !status || voter.status === status;
            const matchesVoted = !voted || 
                                 (voted === 'voted' && voter.voted) ||
                                 (voted === 'not-voted' && !voter.voted);
            
            return matchesSearch && matchesStatus && matchesVoted;
        });
        
        displayVotersPage(1);
    };
    
    searchInput?.addEventListener('input', filterVoters);
    statusFilter?.addEventListener('change', filterVoters);
    votedFilter?.addEventListener('change', filterVoters);
    
    // Pagination buttons
    document.getElementById('prevPage')?.addEventListener('click', () => {
        if (currentPage > 1) displayVotersPage(currentPage - 1);
    });
    
    document.getElementById('nextPage')?.addEventListener('click', () => {
        const totalPages = Math.ceil(filteredVoters.length / votersPerPage);
        if (currentPage < totalPages) displayVotersPage(currentPage + 1);
    });
    
    // Select all checkbox
    document.getElementById('selectAll')?.addEventListener('change', function() {
        document.querySelectorAll('.voters-table tbody input[type="checkbox"]').forEach(cb => {
            cb.checked = this.checked;
        });
    });
}

function viewVoter(id) {
    const voter = AppState.voters.find(v => v.id === id);
    if (!voter) return;
    
    const modalBody = document.getElementById('voterModalBody');
    modalBody.innerHTML = `
        <div class="voter-details">
            <div class="detail-row">
                <span class="detail-label">Voter ID:</span>
                <span class="detail-value">${voter.id}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Name:</span>
                <span class="detail-value">${voter.name}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Email:</span>
                <span class="detail-value">${voter.email}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Department:</span>
                <span class="detail-value">${voter.department}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Status:</span>
                <span class="detail-value"><span class="status-badge-table ${voter.status}">${voter.status}</span></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Has Voted:</span>
                <span class="detail-value">${voter.voted ? 'Yes' : 'No'}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Registration Date:</span>
                <span class="detail-value">${voter.registrationDate}</span>
            </div>
        </div>
    `;
    
    document.getElementById('voterModal').classList.add('show');
}

function editVoter(id) {
    showNotification(`Edit voter ${id} - Feature coming soon`);
}

function flagVoter(id) {
    const voter = AppState.voters.find(v => v.id === id);
    if (voter) {
        voter.status = voter.status === 'flagged' ? 'verified' : 'flagged';
        renderVotersTable();
        showNotification(`Voter ${id} ${voter.status === 'flagged' ? 'flagged' : 'unflagged'}`);
    }
}

function addVoter() {
    showNotification('Add voter feature - Coming soon');
}

function exportVoters() {
    showNotification('Exporting voters to CSV...');
    setTimeout(() => {
        showNotification('Voters exported successfully!');
    }, 1500);
}

// ========================================
// AUDIT & MONITORING
// ========================================
function renderAuditLog() {
    const auditLog = document.getElementById('auditLog');
    if (!auditLog) return;
    
    updateAuditStats();
    displayAuditLog('all');
    
    // Log tabs
    document.querySelectorAll('.log-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.log-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            displayAuditLog(this.getAttribute('data-tab'));
        });
    });
}

function updateAuditStats() {
    const logins = AppState.auditLog.filter(l => l.type === 'login').length;
    const failed = AppState.auditLog.filter(l => l.type === 'security').length;
    const votes = AppState.auditLog.filter(l => l.type === 'vote').length;
    const alerts = AppState.suspiciousAlerts.length;
    
    document.getElementById('totalLogins').textContent = logins;
    document.getElementById('failedLogins').textContent = failed;
    document.getElementById('auditVotes').textContent = votes;
    document.getElementById('securityAlerts').textContent = alerts;
}

function displayAuditLog(filter) {
    const auditLog = document.getElementById('auditLog');
    
    let filtered = AppState.auditLog;
    if (filter !== 'all') {
        filtered = AppState.auditLog.filter(l => l.type === filter);
    }
    
    auditLog.innerHTML = filtered.slice(0, 20).map(log => `
        <div class="log-entry">
            <div class="log-icon ${log.class}">
                <i class="fas fa-${log.icon}"></i>
            </div>
            <div class="log-content">
                <div class="log-title">${log.title}</div>
                <div class="log-details">
                    <span><i class="fas fa-user"></i> ${log.user}</span>
                    <span><i class="fas fa-network-wired"></i> ${log.ip}</span>
                    <span>${log.description}</span>
                </div>
            </div>
            <div class="log-time">${log.time}m ago</div>
        </div>
    `).join('');
}

function setupAuditFilters() {
    document.getElementById('auditTypeFilter')?.addEventListener('change', function() {
        // Filter logic would go here
    });
}

function toggleFilters() {
    document.getElementById('auditFilters').classList.toggle('show');
}

function applyAuditFilters() {
    showNotification('Filters applied');
}

function exportAuditLog() {
    showNotification('Exporting audit log...');
    setTimeout(() => {
        showNotification('Audit log exported successfully!');
    }, 1500);
}

// ========================================
// SECURITY PANEL
// ========================================
function renderSessions() {
    const sessionsList = document.getElementById('sessionsList');
    const activeSessions = document.getElementById('activeSessions');
    
    if (activeSessions) {
        activeSessions.textContent = AppState.sessions.length;
    }
    
    if (sessionsList) {
        sessionsList.innerHTML = AppState.sessions.map(session => `
            <div class="session-item">
                <div class="session-icon">
                    <i class="fas fa-desktop"></i>
                </div>
                <div class="session-info">
                    <div class="session-user">${session.user}</div>
                    <div class="session-meta">${session.device} • ${session.location} • ${session.time}</div>
                </div>
                <div class="session-status"></div>
            </div>
        `).join('');
    }
}

function renderSecurityAlerts() {
    const alertsList = document.getElementById('securityAlertsList');
    const alertCount = document.getElementById('alertCount');
    
    if (alertCount) {
        alertCount.textContent = AppState.suspiciousAlerts.length;
    }
    
    if (alertsList) {
        alertsList.innerHTML = AppState.suspiciousAlerts.map(alert => `
            <div class="security-alert-item">
                <div class="security-alert-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="security-alert-content">
                    <div class="security-alert-title">${alert.title}</div>
                    <div class="security-alert-time">${alert.time}</div>
                </div>
            </div>
        `).join('');
    }
}

function renderSuspiciousAlerts() {
    const alertsList = document.getElementById('suspiciousAlerts');
    if (!alertsList) return;
    
    alertsList.innerHTML = AppState.suspiciousAlerts.map(alert => `
        <div class="alert-item">
            <div class="alert-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="alert-content">
                <div class="alert-title">${alert.title}</div>
                <div class="alert-description">${alert.description}</div>
                <div class="alert-meta">${alert.time}</div>
            </div>
            <div class="alert-actions">
                <button class="action-btn" title="Investigate">
                    <i class="fas fa-search"></i>
                </button>
                <button class="action-btn" title="Dismiss">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function runSecurityScan() {
    showNotification('Running security scan...');
    setTimeout(() => {
        showNotification('Security scan completed. No threats found.');
    }, 2000);
}

function createBackup() {
    showNotification('Creating backup...');
    setTimeout(() => {
        document.getElementById('lastBackup').textContent = 'Just now';
        showNotification('Backup created successfully!');
    }, 2000);
}

function restoreBackup() {
    showNotification('Restore feature - Contact system administrator');
}

// ========================================
// UTILITY FUNCTIONS
// ========================================
function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    const notificationMessage = document.getElementById('notificationMessage');
    
    notificationMessage.textContent = message;
    
    if (type === 'error') {
        notification.style.borderColor = 'var(--danger)';
        notification.querySelector('i').style.color = 'var(--danger)';
    } else {
        notification.style.borderColor = 'var(--success)';
        notification.querySelector('i').style.color = 'var(--success-light)';
    }
    
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

function exportResults(format) {
    showNotification(`Exporting results as ${format.toUpperCase()}...`);
    setTimeout(() => {
        showNotification(`Results exported successfully as ${format.toUpperCase()}!`);
    }, 1500);
}

function refreshResults() {
    showNotification('Refreshing results...');
    updateResults();
    setTimeout(() => {
        showNotification('Results refreshed!');
    }, 1000);
}

function refreshData() {
    showNotification('Refreshing all data...');
    updateDashboardStats();
    updateResults();
    setTimeout(() => {
        showNotification('All data refreshed!');
    }, 1000);
}

function openBroadcast() {
    document.getElementById('broadcastModal').classList.add('show');
}

function sendBroadcast() {
    const message = document.getElementById('broadcastMessage').value;
    if (!message.trim()) {
        showNotification('Please enter a message', 'error');
        return;
    }
    
    closeModal('broadcastModal');
    showNotification('Broadcast message sent successfully!');
    document.getElementById('broadcastMessage').value = '';
}

// Close modals on outside click
window.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal.show').forEach(modal => {
            modal.classList.remove('show');
        });
    }
});

// ========================================
// CLEANUP
// ========================================
window.addEventListener('beforeunload', function() {
    if (AppState.updateInterval) {
        clearInterval(AppState.updateInterval);
    }
});
