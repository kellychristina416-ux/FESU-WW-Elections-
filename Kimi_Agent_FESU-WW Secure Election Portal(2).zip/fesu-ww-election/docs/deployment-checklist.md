# FESU-WW 2026 Election Portal
## Deployment Checklist

**Quick Reference Guide for Production Deployment**

---

## Pre-Deployment Checklist

### Infrastructure Setup

- [ ] **AWS Account Setup**
  - [ ] Production AWS account configured
  - [ ] Billing alerts enabled ($500, $1000, $5000)
  - [ ] Multi-factor authentication on root account
  - [ ] IAM users created with appropriate permissions

- [ ] **VPC Configuration**
  - [ ] VPC created (10.0.0.0/16)
  - [ ] Public subnets created (2+ availability zones)
  - [ ] Private subnets created (2+ availability zones)
  - [ ] Internet Gateway attached
  - [ ] NAT Gateways configured (for private subnets)
  - [ ] Route tables configured

- [ ] **Security Groups**
  - [ ] Application security group created
  - [ ] Database security group created
  - [ ] Load balancer security group created
  - [ ] Bastion host security group created (if applicable)
  - [ ] Rules reviewed and minimized

### Database Setup

- [ ] **RDS PostgreSQL**
  - [ ] Instance created (db.r6g.xlarge or larger)
  - [ ] Encryption at rest enabled
  - [ ] Automated backups configured (30 days)
  - [ ] Multi-AZ enabled
  - [ ] Parameter group optimized
  - [ ] Monitoring enabled (Performance Insights)
  - [ ] Maintenance window configured

- [ ] **ElastiCache Redis**
  - [ ] Cluster created (3 nodes minimum)
  - [ ] Encryption in transit enabled
  - [ ] Encryption at rest enabled
  - [ ] Automatic failover enabled
  - [ ] Parameter group configured

### SSL/TLS Certificates

- [ ] **Certificate Provisioning**
  - [ ] ACM certificate requested for all domains
  - [ ] DNS validation completed
  - [ ] Certificate status: ISSUED
  - [ ] Auto-renewal verified

### Domain & DNS

- [ ] **Route 53 Configuration**
  - [ ] Hosted zone created
  - [ ] A records pointing to ALB
  - [ ] CNAME records for subdomains
  - [ ] Health checks configured
  - [ ] Failover routing (if multi-region)

---

## Application Deployment Checklist

### Environment Preparation

- [ ] **Server Setup**
  ```bash
  # Run on each application server
  sudo apt update && sudo apt upgrade -y
  sudo apt install -y nodejs npm nginx git
  sudo npm install -g pm2
  ```

- [ ] **Directory Structure**
  ```bash
  sudo mkdir -p /opt/fesu-ww/{app,logs,config,keys}
  sudo chown -R ubuntu:ubuntu /opt/fesu-ww
  ```

- [ ] **SSH Key Setup**
  - [ ] Deployment key generated
  - [ ] Public key added to GitHub/GitLab
  - [ ] Private key stored securely (AWS Secrets Manager)

### Code Deployment

- [ ] **Clone Repository**
  ```bash
  cd /opt/fesu-ww/app
  git clone git@github.com:fesu-ww/election-portal.git .
  git checkout production
  ```

- [ ] **Install Dependencies**
  ```bash
  npm ci --production
  ```

- [ ] **Build Application**
  ```bash
  npm run build
  ```

### Configuration

- [ ] **Environment Variables**
  - [ ] `.env.production` file created
  - [ ] All required variables set
  - [ ] Secrets stored in AWS Secrets Manager
  - [ ] File permissions set (600)

- [ ] **Required Environment Variables Checklist**
  ```
  □ NODE_ENV=production
  □ PORT=3000
  □ DATABASE_URL (with credentials)
  □ REDIS_URL (with credentials)
  □ JWT_PRIVATE_KEY_PATH
  □ JWT_PUBLIC_KEY_PATH
  □ ENCRYPTION_KEY (32-byte hex)
  □ TOTP_ENCRYPTION_KEY (32-byte hex)
  □ BLOCKCHAIN_RPC_URL
  □ BLOCKCHAIN_CONTRACT_ADDRESS
  □ BLOCKCHAIN_PRIVATE_KEY
  □ SENDGRID_API_KEY
  □ TWILIO_ACCOUNT_SID
  □ TWILIO_AUTH_TOKEN
  □ CORS_ORIGIN
  □ DATADOG_API_KEY
  □ SENTRY_DSN
  ```

### Database Migration

- [ ] **Run Migrations**
  ```bash
  npx prisma migrate deploy
  ```

- [ ] **Verify Migration Status**
  ```bash
  npx prisma migrate status
  ```

- [ ] **Generate Prisma Client**
  ```bash
  npx prisma generate
  ```

### SSL/TLS Configuration

- [ ] **Nginx SSL Configuration**
  ```bash
  sudo cp /opt/fesu-ww/config/nginx.conf /etc/nginx/sites-available/fesu-ww
  sudo ln -s /etc/nginx/sites-available/fesu-ww /etc/nginx/sites-enabled/
  sudo nginx -t
  sudo systemctl restart nginx
  ```

- [ ] **Certificate Files**
  - [ ] Private key: `/etc/ssl/private/fesu-ww.key`
  - [ ] Certificate: `/etc/ssl/certs/fesu-ww.crt`
  - [ ] CA bundle: `/etc/ssl/certs/ca-bundle.crt`
  - [ ] Permissions: 600 for private key

### Application Startup

- [ ] **PM2 Configuration**
  ```bash
  # ecosystem.config.js
  module.exports = {
    apps: [{
      name: 'fesu-ww-api',
      script: './dist/server.js',
      instances: 'max',
      exec_mode: 'cluster',
      env_production: {
        NODE_ENV: 'production'
      },
      error_file: '/opt/fesu-ww/logs/err.log',
      out_file: '/opt/fesu-ww/logs/out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      max_memory_restart: '1G'
    }]
  };
  ```

- [ ] **Start Application**
  ```bash
  pm2 start ecosystem.config.js --env production
  pm2 save
  pm2 startup systemd
  ```

- [ ] **Verify Application Status**
  ```bash
  pm2 status
  pm2 logs --lines 50
  ```

---

## Blockchain Deployment Checklist

### Smart Contract Deployment

- [ ] **Prerequisites**
  - [ ] Deployer wallet funded (MATIC for gas)
  - [ ] Oracle wallet created and funded
  - [ ] Contract compiled and tested

- [ ] **Deploy Contract**
  ```bash
  npx hardhat run scripts/deploy.js --network polygon
  ```

- [ ] **Record Deployment Info**
  - [ ] Contract address: `_________________________`
  - [ ] Transaction hash: `_________________________`
  - [ ] Block number: `_________________________`
  - [ ] Deployer address: `_________________________`

- [ ] **Grant Oracle Role**
  ```bash
  npx hardhat run scripts/grant-oracle-role.js --network polygon
  ```

- [ ] **Verify Contract on PolygonScan**
  ```bash
  npx hardhat verify --network polygon <CONTRACT_ADDRESS>
  ```

- [ ] **Update Environment**
  - [ ] `BLOCKCHAIN_CONTRACT_ADDRESS` updated in `.env`
  - [ ] Application restarted with new config

---

## Security Configuration Checklist

### Authentication & Authorization

- [ ] **JWT Keys**
  - [ ] RSA key pair generated (4096-bit)
  - [ ] Private key stored securely
  - [ ] Public key distributed to all app servers
  - [ ] Key permissions: 600

- [ ] **Password Policy**
  - [ ] Minimum length: 12 characters
  - [ ] Complexity requirements enabled
  - [ ] Password history: 5 previous passwords
  - [ ] Expiration: 90 days (for admins)

- [ ] **MFA Configuration**
  - [ ] TOTP enabled for all admin accounts
  - [ ] Backup codes generated
  - [ ] Recovery process documented

### Network Security

- [ ] **Cloudflare Configuration**
  - [ ] DNS proxied through Cloudflare
  - [ ] SSL mode: Full (Strict)
  - [ ] Security level: High
  - [ ] DDoS protection enabled
  - [ ] WAF rules configured
  - [ ] Rate limiting enabled
  - [ ] Bot fight mode enabled

- [ ] **AWS WAF**
  - [ ] WebACL created
  - [ ] OWASP ruleset applied
  - [ ] Custom rules configured
  - [ ] Rate-based rules enabled
  - [ ] Associated with ALB

### Data Protection

- [ ] **Encryption at Rest**
  - [ ] RDS encryption enabled
  - [ ] EBS volumes encrypted
  - [ ] S3 buckets encrypted (SSE-S3 or SSE-KMS)
  - [ ] Secrets Manager encryption

- [ ] **Encryption in Transit**
  - [ ] TLS 1.3 enforced
  - [ ] HSTS header configured
  - [ ] Database SSL required
  - [ ] Redis TLS enabled

---

## Load Balancer & CDN Checklist

### Application Load Balancer

- [ ] **ALB Configuration**
  - [ ] ALB created in public subnets
  - [ ] Target group created
  - [ ] Health check configured (`/health`)
  - [ ] SSL certificate attached
  - [ ] Security groups configured
  - [ ] Access logs enabled

- [ ] **Listener Configuration**
  - [ ] HTTPS listener (443) → Target group
  - [ ] HTTP listener (80) → Redirect to HTTPS
  - [ ] SSL policy: ELBSecurityPolicy-TLS13-1-2-2021-06

### Cloudflare CDN

- [ ] **Caching Configuration**
  - [ ] Static assets cached
  - [ ] API responses not cached
  - [ ] Cache TTL configured
  - [ ] Purge cache on deployment

- [ ] **Page Rules**
  - [ ] `/api/*` - Cache level: Bypass
  - [ ] `/static/*` - Cache level: Cache Everything
  - [ ] `/admin/*` - Security level: High

---

## Monitoring & Logging Checklist

### Application Monitoring

- [ ] **Datadog Setup**
  - [ ] Agent installed on all servers
  - [ ] APM enabled for Node.js
  - [ ] Custom metrics configured
  - [ ] Dashboards created
  - [ ] Alerts configured

- [ ] **Sentry Setup**
  - [ ] DSN configured in application
  - [ ] Error tracking enabled
  - [ ] Release tracking configured
  - [ ] Alert rules set up

### Infrastructure Monitoring

- [ ] **CloudWatch**
  - [ ] RDS metrics enabled
  - [ ] ElastiCache metrics enabled
  - [ ] ALB metrics enabled
  - [ ] Custom dashboards created
  - [ ] Alarms configured

- [ ] **Log Aggregation**
  - [ ] Application logs → CloudWatch Logs
  - [ ] Nginx logs → CloudWatch Logs
  - [ ] Database logs → CloudWatch Logs
  - [ ] Log retention: 30 days

### Alerting

- [ ] **Alert Channels**
  - [ ] Email notifications configured
  - [ ] Slack integration enabled
  - [ ] PagerDuty integration (for P1/P2)
  - [ ] SMS alerts (for critical)

---

## Backup & Recovery Checklist

### Database Backups

- [ ] **Automated Backups**
  - [ ] RDS automated backups: 30 days
  - [ ] Backup window configured
  - [ ] Cross-region backup copy enabled

- [ ] **Manual Backup Script**
  ```bash
  # Test backup script
  /opt/fesu-ww/scripts/backup-database.sh
  ```

- [ ] **Backup Verification**
  - [ ] Backup file created successfully
  - [ ] Backup uploaded to S3
  - [ ] Backup can be restored (test monthly)

### Disaster Recovery

- [ ] **Recovery Procedures**
  - [ ] Database restore procedure documented
  - [ ] Application redeploy procedure documented
  - [ ] RTO (Recovery Time Objective): 4 hours
  - [ ] RPO (Recovery Point Objective): 1 hour

---

## Pre-Launch Verification Checklist

### Functional Testing

- [ ] **User Registration**
  - [ ] Registration form works
  - [ ] Email verification sent
  - [ ] Account created successfully

- [ ] **Authentication**
  - [ ] Login works
  - [ ] MFA setup works
  - [ ] Password reset works
  - [ ] Session management works

- [ ] **Voting Flow**
  - [ ] Election list displays
  - [ ] Candidates display correctly
  - [ ] Vote submission works
  - [ ] Receipt generated
  - [ ] Vote verification works

- [ ] **Admin Functions**
  - [ ] Admin login works
  - [ ] Election creation works
  - [ ] Candidate approval works
  - [ ] Results viewing works

### Security Testing

- [ ] **Vulnerability Scan**
  - [ ] Snyk scan: No critical/high issues
  - [ ] OWASP ZAP scan: No critical findings
  - [ ] SSL Labs rating: A+

- [ ] **Penetration Testing**
  - [ ] Authentication bypass tests
  - [ ] SQL injection tests
  - [ ] XSS tests
  - [ ] CSRF tests
  - [ ] Rate limiting tests

### Performance Testing

- [ ] **Load Testing**
  - [ ] 100 concurrent users: Pass
  - [ ] 500 concurrent users: Pass
  - [ ] 1000 concurrent users: Pass
  - [ ] Response time < 500ms (95th percentile)

- [ ] **Stress Testing**
  - [ ] System stable under 2x expected load
  - [ ] Graceful degradation verified
  - [ ] Recovery after load spike verified

---

## Launch Day Checklist

### Pre-Launch (T-2 Hours)

- [ ] **System Health Check**
  - [ ] All services running
  - [ ] No critical alerts
  - [ ] Database connections normal
  - [ ] Cache hit ratio > 80%

- [ ] **Final Backup**
  - [ ] Database backup completed
  - [ ] Configuration backup completed

- [ ] **Communication**
  - [ ] Team notified of launch time
  - [ ] Support team on standby
  - [ ] Incident response team available

### Launch (T-0)

- [ ] **Enable Public Access**
  - [ ] DNS records updated (if not already)
  - [ ] Cloudflare caching purged
  - [ ] Application monitoring active

- [ ] **Smoke Tests**
  - [ ] Homepage loads
  - [ ] Login works
  - [ ] Registration works
  - [ ] Voting flow works

### Post-Launch (T+1 Hour)

- [ ] **Monitoring**
  - [ ] Error rates normal
  - [ ] Response times normal
  - [ ] No unusual traffic patterns
  - [ ] Database performance normal

- [ ] **User Feedback**
  - [ ] Support channel monitored
  - [ ] Social media monitored
  - [ ] No widespread issues reported

---

## Post-Deployment Checklist

### Documentation

- [ ] **Update Documentation**
  - [ ] Architecture diagrams updated
  - [ ] Runbooks updated
  - [ ] Contact lists updated

- [ ] **Knowledge Transfer**
  - [ ] Deployment process documented
  - [ ] Troubleshooting guide updated
  - [ ] Team training completed

### Optimization

- [ ] **Performance Review**
  - [ ] Database query optimization
  - [ ] Cache configuration tuning
  - [ ] CDN cache hit ratio review

- [ ] **Cost Optimization**
  - [ ] Resource utilization review
  - [ ] Reserved instances considered
  - [ ] Unused resources identified

### Maintenance Schedule

- [ ] **Regular Tasks**
  - [ ] Security patches: Weekly
  - [ ] Dependency updates: Monthly
  - [ ] Backup testing: Monthly
  - [ ] Performance review: Monthly
  - [ ] Security audit: Quarterly

---

## Emergency Procedures

### Rollback Procedure

```bash
# 1. Stop current deployment
pm2 stop fesu-ww-api

# 2. Checkout previous version
cd /opt/fesu-ww/app
git log --oneline -5  # Find previous commit
git checkout <PREVIOUS_COMMIT>

# 3. Reinstall dependencies
npm ci --production

# 4. Rebuild
npm run build

# 5. Restart
pm2 start fesu-ww-api

# 6. Verify
pm2 logs
```

### Database Rollback

```bash
# Restore from backup
aws rds restore-db-instance-to-point-in-time \
  --source-db-instance-identifier fesu-ww-production \
  --target-db-instance-identifier fesu-ww-production-restored \
  --restore-time 2025-01-15T10:00:00Z
```

---

## Sign-Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| **Technical Lead** | | | |
| **Security Officer** | | | |
| **Project Manager** | | | |
| **QA Lead** | | | |

---

## Quick Reference Commands

```bash
# Check application status
pm2 status
pm2 logs

# View nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Database connection test
psql $DATABASE_URL -c "SELECT version();"

# Redis connection test
redis-cli -u $REDIS_URL ping

# Check SSL certificate
openssl s_client -connect election.fesu-ww.org:443 -servername election.fesu-ww.org

# Test API health
curl -s https://api.fesu-ww.org/health | jq

# Backup database
/opt/fesu-ww/scripts/backup-database.sh

# Restart services
pm2 restart fesu-ww-api
sudo systemctl restart nginx
```

---

**Document Version:** 1.0.0  
**Last Updated:** January 2025  
**Next Review:** April 2025

---

*This checklist should be completed in its entirety before any production deployment.*
