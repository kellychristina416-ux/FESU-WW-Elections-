# FESU-WW 2026 Election Portal
## Technical Specification & Implementation Guide

**Document Version:** 1.0.0  
**Release Date:** January 2025  
**Classification:** Confidential - Internal Use Only  
**Prepared By:** FESU-WW Technical Committee  
**Review Status:** Pending Approval

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Architecture](#2-system-architecture)
3. [Technology Stack](#3-technology-stack)
4. [Security Specifications](#4-security-specifications)
5. [Database Schema](#5-database-schema)
6. [API Specifications](#6-api-specifications)
7. [Deployment Guide](#7-deployment-guide)
8. [Security Checklist](#8-security-checklist)
9. [Maintenance & Monitoring](#9-maintenance--monitoring)
10. [Appendices](#10-appendices)

---

## 1. Executive Summary

### 1.1 Project Overview

The FESU-WW 2026 Election Portal is a secure, scalable, and transparent digital voting platform designed to facilitate the election of student union representatives for the Federation of Ekureku Students Union World-Wide. The system is engineered to ensure electoral integrity, voter privacy, and auditability while providing a seamless user experience for eligible voters worldwide.

### 1.2 Key Features

| Feature | Description | Priority |
|---------|-------------|----------|
| **Secure Voter Authentication** | Multi-factor authentication (MFA) with JWT and TOTP | Critical |
| **Anonymous Voting** | Cryptographic vote anonymization with zero-knowledge proofs | Critical |
| **Real-time Results** | Live vote tallying with blockchain-backed audit trails | High |
| **Multi-Position Elections** | Support for multiple concurrent electoral positions | High |
| **Global Accessibility** | 99.9% uptime SLA with CDN distribution | High |
| **Mobile Responsive** | Full functionality across all device types | Medium |
| **Admin Dashboard** | Comprehensive election management interface | High |
| **Audit & Reporting** | Immutable audit logs with export capabilities | Critical |

### 1.3 Security Highlights

- **End-to-End Encryption:** All data in transit protected with TLS 1.3
- **Database Encryption:** AES-256 encryption for data at rest
- **Blockchain Integration:** Ethereum-based smart contracts for vote verification
- **DDoS Protection:** Cloudflare Enterprise with 100 Tbps mitigation capacity
- **Penetration Testing:** Quarterly third-party security assessments
- **Compliance:** GDPR, ISO 27001, and SOC 2 Type II aligned

---

## 2. System Architecture

### 2.1 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              CLIENT LAYER                                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │   Web App    │  │  Mobile App  │  │ Admin Portal │  │  Public API  │     │
│  │  (React.js)  │  │  (React Native)│ │  (Vue.js)   │  │  (REST/GraphQL)│    │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘     │
└─────────┼─────────────────┼─────────────────┼─────────────────┼─────────────┘
          │                 │                 │                 │
          └─────────────────┴─────────────────┴─────────────────┘
                                    │
                          ┌─────────┴─────────┐
                          │   Cloudflare CDN  │
                          │  (DDoS/WAF/Cache) │
                          └─────────┬─────────┘
                                    │
┌───────────────────────────────────┼─────────────────────────────────────────┐
│                           APPLICATION LAYER                                  │
│  ┌────────────────────────────────┴────────────────────────────────────┐     │
│  │                        Load Balancer (HAProxy)                      │     │
│  └────────────────────────────────┬────────────────────────────────────┘     │
│                                   │                                          │
│  ┌────────────────────────────────┴────────────────────────────────────┐     │
│  │                     Kubernetes Cluster (EKS/GKE)                    │     │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │     │
│  │  │  API Server  │  │  API Server  │  │  API Server  │              │     │
│  │  │   (Node.js)  │  │   (Node.js)  │  │   (Node.js)  │              │     │
│  │  │  Replica 1   │  │  Replica 2   │  │  Replica N   │              │     │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │     │
│  └────────────────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
┌───────────────────────────────────┼─────────────────────────────────────────┐
│                            DATA LAYER                                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  PostgreSQL  │  │    Redis     │  │  Blockchain  │  │   IPFS       │     │
│  │   (Primary)  │  │   (Cache)    │  │  (Ethereum)  │  │  (Storage)   │     │
│  │  RDS/CloudSQL│  │  ElastiCache │  │   Smart      │  │  (Documents) │     │
│  │              │  │              │  │   Contracts  │  │              │     │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Component Overview

| Component | Technology | Purpose | Scaling |
|-----------|------------|---------|---------|
| **Web Frontend** | React.js 18 + TypeScript | Voter interface | Static (CDN) |
| **Admin Portal** | Vue.js 3 + Pinia | Election management | Static (CDN) |
| **API Gateway** | Kong/AWS API Gateway | Request routing | Horizontal |
| **Application Server** | Node.js 20 (Express) | Business logic | Horizontal |
| **Primary Database** | PostgreSQL 16 | Transactional data | Vertical + Read Replicas |
| **Cache Layer** | Redis 7 | Session & query cache | Cluster |
| **Message Queue** | RabbitMQ | Async processing | Cluster |
| **Blockchain** | Ethereum (Polygon) | Vote verification | External |
| **File Storage** | IPFS + AWS S3 | Document storage | Unlimited |
| **Monitoring** | Prometheus + Grafana | Metrics & alerts | Managed |

### 2.3 Data Flow Diagrams

#### 2.3.1 Voter Authentication Flow

```
┌─────────┐     ┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  Voter  │────▶│   Login     │────▶│   Validate   │────▶│   Generate  │
│         │     │   Portal    │     │   Credentials│     │    JWT      │
└─────────┘     └─────────────┘     └──────────────┘     └──────┬──────┘
                                                                  │
┌─────────┐     ┌─────────────┐     ┌──────────────┐     ┌──────┴──────┐
│  Voter  │◀────│   Verify    │◀────│    Send      │◀────│   Request   │
│         │     │    TOTP     │     │    TOTP      │     │    MFA      │
└─────────┘     └─────────────┘     └──────────────┘     └─────────────┘
```

#### 2.3.2 Vote Casting Flow

```
┌─────────┐     ┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  Voter  │────▶│   Select    │────▶│   Encrypt    │────▶│   Submit    │
│         │     │   Candidate │     │    Vote      │     │    Vote     │
└─────────┘     └─────────────┘     └──────────────┘     └──────┬──────┘
                                                                  │
┌─────────┐     ┌─────────────┐     ┌──────────────┐     ┌──────┴──────┐
│  Voter  │◀────│  Confirm    │◀────│  Blockchain  │◀────│   Store     │
│         │     │  Receipt    │     │   Hash       │     │   in DB     │
└─────────┘     └─────────────┘     └──────────────┘     └─────────────┘
```

---

## 3. Technology Stack

### 3.1 Frontend Technologies

```yaml
Web Application:
  Framework: React.js 18.2+
  Language: TypeScript 5.0+
  State Management: Redux Toolkit 2.0+
  UI Library: Material-UI (MUI) 5.14+
  Forms: React Hook Form 7.47+
  Validation: Zod 3.22+
  HTTP Client: Axios 1.6+
  Testing: Jest 29 + React Testing Library 14

Admin Portal:
  Framework: Vue.js 3.3+
  Language: TypeScript 5.0+
  State Management: Pinia 2.1+
  UI Library: Vuetify 3.4+
  Charts: Chart.js 4.4+
  Tables: AG Grid 31.0+

Mobile Application:
  Framework: React Native 0.73+
  Navigation: React Navigation 6.1+
  Storage: AsyncStorage 1.19+
  Biometrics: React Native Biometrics 3.0+
```

### 3.2 Backend Technologies

```yaml
Runtime:
  Platform: Node.js 20 LTS
  Framework: Express.js 4.18+
  Language: TypeScript 5.0+

Core Libraries:
  ORM: Prisma 5.7+
  Validation: Joi 17.11 + Zod 3.22
  Authentication: Passport.js 0.7 + jsonwebtoken 9.0
  Encryption: bcrypt 5.1 + crypto-js 4.2
  Rate Limiting: express-rate-limit 7.1
  Security: helmet 7.1 + cors 2.8
  Logging: Winston 3.11 + Morgan 1.10
  Documentation: Swagger/OpenAPI 3.0

Testing:
  Framework: Jest 29.7 + Supertest 6.3
  Coverage: Istanbul/nyc
  E2E: Cypress 13.6
```

### 3.3 Database Specifications

```yaml
Primary Database:
  Engine: PostgreSQL 16.1
  Hosting: AWS RDS / Google Cloud SQL
  Instance: db.r6g.2xlarge (minimum)
  Storage: 500GB SSD (expandable)
  Backup: Automated daily + point-in-time recovery
  Encryption: AES-256 at rest
  SSL: Required for all connections

Cache Database:
  Engine: Redis 7.2
  Hosting: AWS ElastiCache / Redis Cloud
  Cluster Mode: Enabled (6 shards)
  Persistence: AOF + RDB snapshots
  Eviction Policy: allkeys-lru

Search Engine:
  Engine: Elasticsearch 8.11
  Use Case: Audit log search, voter lookup
  Shards: 3 primary + 1 replica
```

### 3.4 Security Technologies

```yaml
Transport Security:
  Protocol: TLS 1.3 (mandatory)
  Certificate: Let's Encrypt / AWS ACM
  HSTS: max-age=31536000; includeSubDomains; preload
  Cipher Suites: TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256

Authentication:
  Primary: JWT (RS256 algorithm)
  Secondary: TOTP (RFC 6238 compliant)
  Backup: Recovery codes (12 codes, single-use)
  Session: Redis-backed with 30-min timeout

Application Security:
  WAF: Cloudflare / AWS WAF
  DDoS Protection: Cloudflare Magic Transit
  Bot Management: Cloudflare Bot Fight Mode
  Input Sanitization: DOMPurify + validator.js
  SQL Injection: Parameterized queries (Prisma)
  XSS Protection: Content Security Policy v3
```

### 3.5 Third-Party Services

| Service | Provider | Purpose | Integration |
|---------|----------|---------|-------------|
| **CDN** | Cloudflare | Content delivery, DDoS protection | Full proxy |
| **Email** | SendGrid/AWS SES | Transactional emails | SMTP/API |
| **SMS** | Twilio | TOTP delivery, notifications | REST API |
| **Blockchain** | Polygon | Vote verification | Web3.js/Ethers.js |
| **Monitoring** | Datadog | APM, logs, infrastructure | Agent |
| **Secrets** | AWS Secrets Manager | Credential management | SDK |
| **File Storage** | AWS S3 + IPFS | Document storage | SDK |

---

## 4. Security Specifications

### 4.1 SSL/TLS Configuration (TLS 1.3 with HSTS)

#### Nginx Configuration

```nginx
# /etc/nginx/conf.d/ssl.conf

server {
    listen 443 ssl http2;
    server_name election.fesu-ww.org;
    
    # TLS 1.3 Only
    ssl_protocols TLSv1.3;
    ssl_prefer_server_ciphers off;
    
    # Modern Cipher Suites
    ssl_ciphers TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256;
    
    # Certificate Configuration
    ssl_certificate /etc/ssl/certs/fesu-ww.crt;
    ssl_certificate_key /etc/ssl/private/fesu-ww.key;
    ssl_trusted_certificate /etc/ssl/certs/ca-chain.crt;
    
    # OCSP Stapling
    ssl_stapling on;
    ssl_stapling_verify on;
    resolver 8.8.8.8 8.8.4.4 valid=300s;
    resolver_timeout 5s;
    
    # Session Configuration
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:50m;
    ssl_session_tickets off;
    
    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self' https://api.fesu-ww.org; frame-ancestors 'none'; base-uri 'self'; form-action 'self';" always;
    
    # Location blocks...
}

# HTTP to HTTPS redirect
server {
    listen 80;
    server_name election.fesu-ww.org;
    return 301 https://$server_name$request_uri;
}
```

### 4.2 Database Encryption (AES-256)

#### PostgreSQL Encryption Configuration

```sql
-- Enable pgcrypto extension for encryption
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Function to encrypt sensitive data
CREATE OR REPLACE FUNCTION encrypt_sensitive(data TEXT, key TEXT)
RETURNS BYTEA AS $$
BEGIN
    RETURN pgp_sym_encrypt(data, key, 'cipher-algo=aes256');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to decrypt sensitive data
CREATE OR REPLACE FUNCTION decrypt_sensitive(encrypted_data BYTEA, key TEXT)
RETURNS TEXT AS $$
BEGIN
    RETURN pgp_sym_decrypt(encrypted_data, key);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Example: Encrypted voter phone number
ALTER TABLE voters ADD COLUMN phone_encrypted BYTEA;
UPDATE voters SET phone_encrypted = encrypt_sensitive(phone, current_setting('app.encryption_key'));
```

#### Application-Level Encryption (Node.js)

```typescript
// src/utils/encryption.ts
import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;

export class EncryptionService {
  private key: Buffer;

  constructor(encryptionKey: string) {
    this.key = Buffer.from(encryptionKey, 'hex');
    if (this.key.length !== KEY_LENGTH) {
      throw new Error('Invalid encryption key length');
    }
  }

  encrypt(plaintext: string): { encrypted: string; iv: string; authTag: string } {
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, this.key, iv);
    
    let encrypted = cipher.update(plaintext, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    return {
      encrypted,
      iv: iv.toString('hex'),
      authTag: authTag.toString('hex')
    };
  }

  decrypt(encrypted: string, iv: string, authTag: string): string {
    const decipher = crypto.createDecipheriv(
      ALGORITHM,
      this.key,
      Buffer.from(iv, 'hex')
    );
    
    decipher.setAuthTag(Buffer.from(authTag, 'hex'));
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }
}
```

### 4.3 Authentication Protocols (JWT + TOTP)

#### JWT Implementation

```typescript
// src/services/auth/jwt.service.ts
import jwt from 'jsonwebtoken';
import { Redis } from 'ioredis';

interface TokenPayload {
  userId: string;
  email: string;
  role: 'voter' | 'admin' | 'superadmin';
  iat: number;
  exp: number;
  jti: string; // JWT ID for revocation
}

export class JWTService {
  private readonly ACCESS_TOKEN_EXPIRY = '15m';
  private readonly REFRESH_TOKEN_EXPIRY = '7d';
  private redis: Redis;

  constructor(
    private privateKey: string,
    private publicKey: string,
    redisClient: Redis
  ) {
    this.redis = redisClient;
  }

  generateTokens(userId: string, email: string, role: string) {
    const jti = crypto.randomUUID();
    
    const accessToken = jwt.sign(
      { userId, email, role, jti },
      this.privateKey,
      { 
        algorithm: 'RS256',
        expiresIn: this.ACCESS_TOKEN_EXPIRY 
      }
    );

    const refreshJti = crypto.randomUUID();
    const refreshToken = jwt.sign(
      { userId, jti: refreshJti, type: 'refresh' },
      this.privateKey,
      { 
        algorithm: 'RS256',
        expiresIn: this.REFRESH_TOKEN_EXPIRY 
      }
    );

    // Store refresh token in Redis for revocation capability
    this.redis.setex(
      `refresh:${userId}:${refreshJti}`,
      7 * 24 * 60 * 60, // 7 days
      'valid'
    );

    return { accessToken, refreshToken, jti };
  }

  async verifyAccessToken(token: string): Promise<TokenPayload> {
    try {
      const decoded = jwt.verify(token, this.publicKey, {
        algorithms: ['RS256']
      }) as TokenPayload;

      // Check if token is blacklisted
      const isBlacklisted = await this.redis.get(`blacklist:${decoded.jti}`);
      if (isBlacklisted) {
        throw new Error('Token has been revoked');
      }

      return decoded;
    } catch (error) {
      throw new Error('Invalid or expired token');
    }
  }

  async revokeToken(jti: string, exp: number): Promise<void> {
    const ttl = exp - Math.floor(Date.now() / 1000);
    if (ttl > 0) {
      await this.redis.setex(`blacklist:${jti}`, ttl, 'revoked');
    }
  }
}
```

#### TOTP Implementation

```typescript
// src/services/auth/totp.service.ts
import { authenticator } from 'otplib';
import QRCode from 'qrcode';

export class TOTPService {
  constructor() {
    authenticator.options = {
      digits: 6,
      step: 30,
      window: 1, // Allow 1 step before/after for time drift
    };
  }

  generateSecret(): string {
    return authenticator.generateSecret();
  }

  generateQRCode(email: string, secret: string, issuer: string = 'FESU-WW'): Promise<string> {
    const otpauth = authenticator.keyuri(email, issuer, secret);
    return QRCode.toDataURL(otpauth);
  }

  verifyToken(token: string, secret: string): boolean {
    return authenticator.verify({ token, secret });
  }

  generateBackupCodes(count: number = 12): string[] {
    const codes: string[] = [];
    for (let i = 0; i < count; i++) {
      // Generate 8-character alphanumeric codes
      const code = crypto.randomBytes(4).toString('hex').toUpperCase();
      codes.push(code);
    }
    return codes;
  }
}
```

### 4.4 Blockchain Integration (Audit Trail)

#### Smart Contract (Solidity)

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

/**
 * @title FESU-WW Election Smart Contract
 * @dev Immutable vote recording and verification system
 */
contract FESUElection is AccessControl, ReentrancyGuard {
    bytes32 public constant AUDITOR_ROLE = keccak256("AUDITOR_ROLE");
    bytes32 public constant ORACLE_ROLE = keccak256("ORACLE_ROLE");
    
    struct Vote {
        bytes32 voteHash;      // Hash of vote data
        bytes32 nullifier;     // Prevents double voting
        uint256 timestamp;     // Block timestamp
        uint256 electionId;    // Election identifier
    }
    
    struct Election {
        string name;
        uint256 startTime;
        uint256 endTime;
        bool isActive;
        uint256 totalVotes;
        mapping(bytes32 => bool) nullifiers; // Track used nullifiers
    }
    
    // State variables
    mapping(uint256 => Election) public elections;
    mapping(bytes32 => Vote) public votes;
    mapping(uint256 => bytes32[]) public electionVotes;
    
    uint256 public electionCount;
    bytes32[] public allVoteHashes;
    
    // Events
    event ElectionCreated(uint256 indexed electionId, string name, uint256 startTime, uint256 endTime);
    event VoteCast(uint256 indexed electionId, bytes32 indexed voteHash, bytes32 nullifier, uint256 timestamp);
    event ElectionClosed(uint256 indexed electionId, uint256 totalVotes);
    
    constructor() {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _grantRole(AUDITOR_ROLE, msg.sender);
    }
    
    /**
     * @dev Create a new election
     */
    function createElection(
        string memory _name,
        uint256 _startTime,
        uint256 _endTime
    ) external onlyRole(DEFAULT_ADMIN_ROLE) returns (uint256) {
        require(_endTime > _startTime, "Invalid time range");
        require(_startTime > block.timestamp, "Start time must be in future");
        
        uint256 electionId = electionCount++;
        Election storage election = elections[electionId];
        election.name = _name;
        election.startTime = _startTime;
        election.endTime = _endTime;
        election.isActive = true;
        
        emit ElectionCreated(electionId, _name, _startTime, _endTime);
        return electionId;
    }
    
    /**
     * @dev Record a vote on the blockchain
     */
    function recordVote(
        uint256 _electionId,
        bytes32 _voteHash,
        bytes32 _nullifier
    ) external onlyRole(ORACLE_ROLE) nonReentrant returns (bool) {
        Election storage election = elections[_electionId];
        
        require(election.isActive, "Election not active");
        require(block.timestamp >= election.startTime, "Election not started");
        require(block.timestamp <= election.endTime, "Election ended");
        require(!election.nullifiers[_nullifier], "Vote already cast");
        require(votes[_voteHash].timestamp == 0, "Vote hash exists");
        
        // Record vote
        election.nullifiers[_nullifier] = true;
        election.totalVotes++;
        
        votes[_voteHash] = Vote({
            voteHash: _voteHash,
            nullifier: _nullifier,
            timestamp: block.timestamp,
            electionId: _electionId
        });
        
        electionVotes[_electionId].push(_voteHash);
        allVoteHashes.push(_voteHash);
        
        emit VoteCast(_electionId, _voteHash, _nullifier, block.timestamp);
        return true;
    }
    
    /**
     * @dev Verify if a vote exists on the blockchain
     */
    function verifyVote(bytes32 _voteHash) external view returns (bool exists, uint256 timestamp, uint256 electionId) {
        Vote memory vote = votes[_voteHash];
        exists = vote.timestamp != 0;
        timestamp = vote.timestamp;
        electionId = vote.electionId;
    }
    
    /**
     * @dev Get total votes for an election
     */
    function getElectionVoteCount(uint256 _electionId) external view returns (uint256) {
        return elections[_electionId].totalVotes;
    }
    
    /**
     * @dev Close an election
     */
    function closeElection(uint256 _electionId) external onlyRole(DEFAULT_ADMIN_ROLE) {
        Election storage election = elections[_electionId];
        require(election.isActive, "Election already closed");
        
        election.isActive = false;
        emit ElectionClosed(_electionId, election.totalVotes);
    }
}
```

#### Web3 Integration (Node.js)

```typescript
// src/services/blockchain/vote.service.ts
import { ethers } from 'ethers';
import FESUElectionABI from './abis/FESUElection.json';

export class BlockchainVoteService {
  private contract: ethers.Contract;
  private provider: ethers.Provider;
  private wallet: ethers.Wallet;

  constructor(
    rpcUrl: string,
    contractAddress: string,
    privateKey: string
  ) {
    this.provider = new ethers.JsonRpcProvider(rpcUrl);
    this.wallet = new ethers.Wallet(privateKey, this.provider);
    this.contract = new ethers.Contract(
      contractAddress,
      FESUElectionABI,
      this.wallet
    );
  }

  async recordVote(
    electionId: number,
    voteHash: string,
    nullifier: string
  ): Promise<{ transactionHash: string; blockNumber: number }> {
    const tx = await this.contract.recordVote(
      electionId,
      voteHash,
      nullifier
    );
    
    const receipt = await tx.wait();
    
    return {
      transactionHash: receipt.hash,
      blockNumber: receipt.blockNumber
    };
  }

  async verifyVote(voteHash: string): Promise<{
    exists: boolean;
    timestamp: number;
    electionId: number;
  }> {
    const result = await this.contract.verifyVote(voteHash);
    return {
      exists: result.exists,
      timestamp: Number(result.timestamp),
      electionId: Number(result.electionId)
    };
  }

  async getTransactionReceipt(txHash: string): Promise<ethers.TransactionReceipt | null> {
    return await this.provider.getTransactionReceipt(txHash);
  }
}
```

### 4.5 Firewall and DDoS Protection

#### Cloudflare Configuration

```yaml
# Cloudflare Zone Settings
dns:
  proxied: true
  ssl: strict

security:
  security_level: high
  challenge_ttl: 1800
  browser_integrity_check: true
  
  # DDoS Protection
  ddos:
    mode: high
    sensitivity: default
    
  # WAF Rules
  waf:
    mode: on
    rulesets:
      - owasp_core_ruleset
      - fesu_custom_ruleset
      
  # Rate Limiting
  rate_limiting:
    enabled: true
    rules:
      - name: "API Rate Limit"
        threshold: 100
        period: 60
        action: challenge
        match:
          request:
            url: "/api/*"
            methods: [POST, PUT, DELETE]
            
      - name: "Login Rate Limit"
        threshold: 5
        period: 300
        action: block
        match:
          request:
            url: "/api/auth/login"
            methods: [POST]
            
      - name: "Vote Submission Limit"
        threshold: 3
        period: 60
        action: block
        match:
          request:
            url: "/api/votes/submit"
            methods: [POST]

  # Bot Management
  bot_management:
    mode: fight
    auto_update: true
    
  # IP Access Rules
  ip_access_rules:
    - value: "10.0.0.0/8"
      mode: whitelist
      note: "Internal network"
    - value: "192.168.0.0/16"
      mode: whitelist
      note: "VPN network"
```

### 4.6 Session Management

```typescript
// src/services/session/session.service.ts
import { Redis } from 'ioredis';
import crypto from 'crypto';

interface SessionData {
  userId: string;
  email: string;
  role: string;
  mfaVerified: boolean;
  ipAddress: string;
  userAgent: string;
  createdAt: number;
  lastActivity: number;
}

export class SessionService {
  private readonly SESSION_TTL = 1800; // 30 minutes
  private readonly MAX_SESSIONS_PER_USER = 3;
  
  constructor(private redis: Redis) {}

  async createSession(userId: string, data: Omit<SessionData, 'createdAt' | 'lastActivity'>): Promise<string> {
    const sessionId = crypto.randomBytes(32).toString('hex');
    const now = Date.now();
    
    const sessionData: SessionData = {
      ...data,
      userId,
      createdAt: now,
      lastActivity: now
    };

    // Enforce maximum sessions per user
    const userSessionsKey = `user_sessions:${userId}`;
    const existingSessions = await this.redis.smembers(userSessionsKey);
    
    if (existingSessions.length >= this.MAX_SESSIONS_PER_USER) {
      // Remove oldest session
      const oldestSession = existingSessions[0];
      await this.destroySession(oldestSession);
    }

    // Store session
    await this.redis.setex(
      `session:${sessionId}`,
      this.SESSION_TTL,
      JSON.stringify(sessionData)
    );

    // Track user's sessions
    await this.redis.sadd(userSessionsKey, sessionId);
    await this.redis.expire(userSessionsKey, this.SESSION_TTL);

    return sessionId;
  }

  async getSession(sessionId: string): Promise<SessionData | null> {
    const data = await this.redis.get(`session:${sessionId}`);
    if (!data) return null;
    
    return JSON.parse(data) as SessionData;
  }

  async refreshSession(sessionId: string): Promise<void> {
    const data = await this.getSession(sessionId);
    if (!data) return;

    data.lastActivity = Date.now();
    
    await this.redis.setex(
      `session:${sessionId}`,
      this.SESSION_TTL,
      JSON.stringify(data)
    );
  }

  async destroySession(sessionId: string): Promise<void> {
    const data = await this.getSession(sessionId);
    if (data) {
      await this.redis.srem(`user_sessions:${data.userId}`, sessionId);
    }
    await this.redis.del(`session:${sessionId}`);
  }

  async destroyAllUserSessions(userId: string): Promise<void> {
    const sessionIds = await this.redis.smembers(`user_sessions:${userId}`);
    
    const pipeline = this.redis.pipeline();
    sessionIds.forEach(id => pipeline.del(`session:${id}`));
    pipeline.del(`user_sessions:${userId}`);
    
    await pipeline.exec();
  }
}
```

### 4.7 Input Validation and Sanitization

```typescript
// src/middleware/validation.middleware.ts
import { Request, Response, NextFunction } from 'express';
import { z, ZodError } from 'zod';
import DOMPurify from 'isomorphic-dompurify';

// Sanitization middleware
export const sanitizeInput = (req: Request, res: Response, next: NextFunction) => {
  const sanitize = (obj: any): any => {
    if (typeof obj === 'string') {
      return DOMPurify.sanitize(obj, {
        ALLOWED_TAGS: [],
        ALLOWED_ATTR: [],
        KEEP_CONTENT: true
      });
    }
    if (Array.isArray(obj)) {
      return obj.map(sanitize);
    }
    if (obj && typeof obj === 'object') {
      return Object.fromEntries(
        Object.entries(obj).map(([key, value]) => [key, sanitize(value)])
      );
    }
    return obj;
  };

  req.body = sanitize(req.body);
  req.query = sanitize(req.query);
  req.params = sanitize(req.params);
  
  next();
};

// Validation schemas
export const schemas = {
  login: z.object({
    email: z.string().email('Invalid email format').max(255),
    password: z.string().min(8).max(128),
    totpCode: z.string().length(6).regex(/^\d+$/).optional()
  }),

  vote: z.object({
    electionId: z.number().int().positive(),
    candidateId: z.number().int().positive(),
    positionId: z.number().int().positive()
  }),

  register: z.object({
    email: z.string().email().max(255),
    password: z.string()
      .min(12)
      .max(128)
      .regex(/[A-Z]/, 'Must contain uppercase')
      .regex(/[a-z]/, 'Must contain lowercase')
      .regex(/[0-9]/, 'Must contain number')
      .regex(/[^A-Za-z0-9]/, 'Must contain special character'),
    firstName: z.string().min(2).max(100),
    lastName: z.string().min(2).max(100),
    studentId: z.string().regex(/^FESU\d{6}$/),
    phone: z.string().regex(/^\+?[1-9]\d{1,14}$/)
  }),

  election: z.object({
    name: z.string().min(3).max(200),
    description: z.string().max(2000).optional(),
    startDate: z.string().datetime(),
    endDate: z.string().datetime(),
    positions: z.array(z.object({
      name: z.string().min(2).max(100),
      description: z.string().max(500).optional(),
      maxSelections: z.number().int().min(1).max(10).default(1)
    })).min(1)
  })
};

// Validation middleware factory
export const validate = (schema: z.ZodSchema) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          error: 'Validation failed',
          details: error.errors.map(e => ({
            field: e.path.join('.'),
            message: e.message
          }))
        });
      }
      next(error);
    }
  };
};
```

### 4.8 Rate Limiting

```typescript
// src/middleware/rate-limit.middleware.ts
import rateLimit from 'express-rate-limit';
import { RedisStore } from 'rate-limit-redis';
import { Redis } from 'ioredis';

export const createRateLimiters = (redis: Redis) => ({
  // General API rate limiter
  api: rateLimit({
    store: new RedisStore({
      sendCommand: (...args: string[]) => redis.call(...args),
      prefix: 'rl:api:'
    }),
    windowMs: 60 * 1000, // 1 minute
    max: 100,
    message: {
      error: 'Too many requests',
      retryAfter: 60
    },
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => req.ip || 'unknown'
  }),

  // Authentication rate limiter (stricter)
  auth: rateLimit({
    store: new RedisStore({
      sendCommand: (...args: string[]) => redis.call(...args),
      prefix: 'rl:auth:'
    }),
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5,
    skipSuccessfulRequests: true,
    message: {
      error: 'Too many login attempts',
      retryAfter: 900
    },
    standardHeaders: true,
    legacyHeaders: false
  }),

  // Vote submission rate limiter (very strict)
  vote: rateLimit({
    store: new RedisStore({
      sendCommand: (...args: string[]) => redis.call(...args),
      prefix: 'rl:vote:'
    }),
    windowMs: 60 * 1000, // 1 minute
    max: 3,
    message: {
      error: 'Too many vote submissions',
      retryAfter: 60
    },
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => req.user?.id || req.ip
  }),

  // Admin operations rate limiter
  admin: rateLimit({
    store: new RedisStore({
      sendCommand: (...args: string[]) => redis.call(...args),
      prefix: 'rl:admin:'
    }),
    windowMs: 60 * 1000,
    max: 30,
    message: {
      error: 'Too many admin operations',
      retryAfter: 60
    },
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => req.user?.id || req.ip
  })
});
```

---

## 5. Database Schema

### 5.1 Entity Relationship Diagram

```
┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
│     voters      │       │  voter_sessions │       │  login_attempts │
├─────────────────┤       ├─────────────────┤       ├─────────────────┤
│ id (PK)         │◀──────│ voter_id (FK)   │       │ id (PK)         │
│ email           │       │ session_token   │       │ voter_id (FK)   │
│ password_hash   │       │ expires_at      │       │ ip_address      │
│ student_id      │       │ created_at      │       │ user_agent      │
│ first_name      │       └─────────────────┘       │ success         │
│ last_name       │                                 │ created_at      │
│ phone_encrypted │                                 └─────────────────┘
│ is_verified     │
│ created_at      │       ┌─────────────────┐       ┌─────────────────┐
│ updated_at      │       │  elections      │       │    positions    │
└─────────────────┘       ├─────────────────┤       ├─────────────────┤
                          │ id (PK)         │◀──────│ election_id(FK) │
                          │ name            │       │ id (PK)         │
                          │ description     │       │ name            │
                          │ start_date      │       │ description     │
                          │ end_date        │       │ max_selections  │
                          │ status          │       │ display_order   │
                          │ created_by(FK)  │       └─────────────────┘
                          │ created_at      │
                          │ updated_at      │       ┌─────────────────┐
                          └─────────────────┘       │   candidates    │
                                   │                ├─────────────────┤
                                   │                │ id (PK)         │
                                   │                │ position_id(FK) │◀┐
                                   │                │ voter_id (FK)   │ │
                                   │                │ manifesto       │ │
                                   │                │ photo_url       │ │
                                   │                │ is_approved     │ │
                                   │                │ created_at      │ │
                                   │                └─────────────────┘ │
                                   │                                      │
                                   │                ┌─────────────────┐   │
                                   │                │      votes      │   │
                                   │                ├─────────────────┤   │
                                   └───────────────▶│ election_id(FK) │   │
                                                    │ position_id(FK) │───┘
                                                    │ candidate_id(FK)│
                                                    │ voter_hash      │
                                                    │ blockchain_tx   │
                                                    │ created_at      │
                                                    └─────────────────┘
```

### 5.2 Voters Table Structure

```sql
-- Voters table (registered eligible voters)
CREATE TABLE voters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    student_id VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone_encrypted BYTEA,
    date_of_birth DATE,
    graduation_year INTEGER,
    chapter VARCHAR(100), -- FESU chapter/branch
    country_code CHAR(2),
    
    -- Verification status
    is_email_verified BOOLEAN DEFAULT FALSE,
    is_identity_verified BOOLEAN DEFAULT FALSE,
    verification_documents JSONB,
    
    -- MFA settings
    totp_secret_encrypted BYTEA,
    backup_codes_hash TEXT[],
    mfa_enabled BOOLEAN DEFAULT FALSE,
    
    -- Account status
    is_active BOOLEAN DEFAULT TRUE,
    is_blocked BOOLEAN DEFAULT FALSE,
    block_reason TEXT,
    blocked_at TIMESTAMP WITH TIME ZONE,
    
    -- Metadata
    last_login_at TIMESTAMP WITH TIME ZONE,
    last_login_ip INET,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT valid_student_id CHECK (student_id ~ '^FESU[0-9]{6}$')
);

-- Indexes
CREATE INDEX idx_voters_email ON voters(email);
CREATE INDEX idx_voters_student_id ON voters(student_id);
CREATE INDEX idx_voters_chapter ON voters(chapter);
CREATE INDEX idx_voters_active ON voters(is_active) WHERE is_active = TRUE;
```

### 5.3 Candidates Table Structure

```sql
-- Candidates table (election candidates)
CREATE TABLE candidates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    position_id UUID NOT NULL REFERENCES positions(id) ON DELETE CASCADE,
    voter_id UUID NOT NULL REFERENCES voters(id) ON DELETE CASCADE,
    
    -- Candidate information
    manifesto TEXT NOT NULL,
    manifesto_summary VARCHAR(500),
    photo_url VARCHAR(500),
    campaign_video_url VARCHAR(500),
    social_links JSONB,
    
    -- Academic/Professional background
    qualifications JSONB,
    achievements JSONB,
    previous_roles TEXT[],
    
    -- Campaign status
    nomination_status VARCHAR(20) DEFAULT 'pending' 
        CHECK (nomination_status IN ('pending', 'approved', 'rejected', 'withdrawn')),
    nominated_by UUID REFERENCES voters(id),
    seconded_by UUID REFERENCES voters(id),
    
    -- Approval workflow
    reviewed_by UUID REFERENCES admin_users(id),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    rejection_reason TEXT,
    
    -- Display order
    ballot_number INTEGER,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT unique_candidate_per_position UNIQUE (position_id, voter_id),
    CONSTRAINT valid_ballot_number CHECK (ballot_number > 0)
);

-- Indexes
CREATE INDEX idx_candidates_position ON candidates(position_id);
CREATE INDEX idx_candidates_voter ON candidates(voter_id);
CREATE INDEX idx_candidates_status ON candidates(nomination_status);
CREATE INDEX idx_candidates_ballot ON candidates(position_id, ballot_number);
```

### 5.4 Votes Table Structure

```sql
-- Votes table (anonymous vote records)
CREATE TABLE votes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    election_id UUID NOT NULL REFERENCES elections(id),
    position_id UUID NOT NULL REFERENCES positions(id),
    candidate_id UUID NOT NULL REFERENCES candidates(id),
    
    -- Anonymization
    voter_hash VARCHAR(64) NOT NULL, -- SHA-256 hash of voter_id + election_id + secret
    nullifier VARCHAR(64) NOT NULL UNIQUE, -- Prevents double voting
    
    -- Vote verification
    vote_proof TEXT, -- Zero-knowledge proof
    blockchain_tx_hash VARCHAR(66), -- Ethereum transaction hash
    blockchain_block_number BIGINT,
    blockchain_timestamp TIMESTAMP WITH TIME ZONE,
    
    -- Vote metadata (non-identifying)
    voting_method VARCHAR(20) DEFAULT 'web' 
        CHECK (voting_method IN ('web', 'mobile', 'admin')),
    ip_hash VARCHAR(64), -- Hashed IP for fraud detection
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT unique_vote_per_position UNIQUE (election_id, position_id, voter_hash)
);

-- Indexes
CREATE INDEX idx_votes_election ON votes(election_id);
CREATE INDEX idx_votes_position ON votes(position_id);
CREATE INDEX idx_votes_candidate ON votes(candidate_id);
CREATE INDEX idx_votes_nullifier ON votes(nullifier);
CREATE INDEX idx_votes_blockchain ON votes(blockchain_tx_hash);
CREATE INDEX idx_votes_created ON votes(created_at);

-- Materialized view for vote counts (refreshed periodically)
CREATE MATERIALIZED VIEW vote_counts AS
SELECT 
    election_id,
    position_id,
    candidate_id,
    COUNT(*) as vote_count
FROM votes
GROUP BY election_id, position_id, candidate_id;

CREATE UNIQUE INDEX idx_vote_counts ON vote_counts(election_id, position_id, candidate_id);
```

### 5.5 Audit Logs Table Structure

```sql
-- Comprehensive audit logging
CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    
    -- Event identification
    event_type VARCHAR(50) NOT NULL,
    event_category VARCHAR(30) NOT NULL 
        CHECK (event_category IN ('authentication', 'authorization', 'voting', 'admin', 'system', 'security')),
    
    -- Actor information
    actor_type VARCHAR(20) NOT NULL 
        CHECK (actor_type IN ('voter', 'admin', 'system', 'anonymous')),
    actor_id UUID,
    actor_email VARCHAR(255),
    
    -- Action details
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50),
    resource_id UUID,
    
    -- Request context
    ip_address INET,
    user_agent TEXT,
    request_id UUID,
    session_id VARCHAR(128),
    
    -- Data changes (for update operations)
    old_data JSONB,
    new_data JSONB,
    
    -- Result
    success BOOLEAN NOT NULL,
    error_code VARCHAR(50),
    error_message TEXT,
    
    -- Integrity
    log_hash VARCHAR(64) NOT NULL, -- SHA-256 hash for chain validation
    previous_log_hash VARCHAR(64), -- Links to previous log entry
    
    -- Timestamp
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Additional metadata
    metadata JSONB
);

-- Indexes for efficient querying
CREATE INDEX idx_audit_created ON audit_logs(created_at);
CREATE INDEX idx_audit_event_type ON audit_logs(event_type);
CREATE INDEX idx_audit_actor ON audit_logs(actor_id);
CREATE INDEX idx_audit_category ON audit_logs(event_category);
CREATE INDEX idx_audit_resource ON audit_logs(resource_type, resource_id);
CREATE INDEX idx_audit_request ON audit_logs(request_id);

-- Partitioning for performance (by month)
CREATE TABLE audit_logs_2025_01 PARTITION OF audit_logs
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');

-- Trigger for hash chain
CREATE OR REPLACE FUNCTION calculate_log_hash()
RETURNS TRIGGER AS $$
BEGIN
    -- Get previous log hash
    SELECT log_hash INTO NEW.previous_log_hash
    FROM audit_logs
    ORDER BY id DESC
    LIMIT 1;
    
    -- Calculate new hash
    NEW.log_hash := encode(
        digest(
            concat(
                NEW.event_type, '|',
                NEW.actor_id::text, '|',
                NEW.action, '|',
                NEW.created_at::text, '|',
                COALESCE(NEW.previous_log_hash, 'genesis')
            ),
            'sha256'
        ),
        'hex'
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_log_hash
    BEFORE INSERT ON audit_logs
    FOR EACH ROW
    EXECUTE FUNCTION calculate_log_hash();
```

### 5.6 Admin Users Table Structure

```sql
-- Admin users table
CREATE TABLE admin_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Basic info
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    
    -- Role-based access control
    role VARCHAR(30) NOT NULL 
        CHECK (role IN ('superadmin', 'election_admin', 'auditor', 'support')),
    permissions JSONB DEFAULT '[]',
    
    -- MFA
    totp_secret_encrypted BYTEA,
    mfa_enabled BOOLEAN DEFAULT TRUE,
    
    -- Account status
    is_active BOOLEAN DEFAULT TRUE,
    last_password_change TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    password_expires_at TIMESTAMP WITH TIME ZONE DEFAULT (CURRENT_TIMESTAMP + INTERVAL '90 days'),
    
    -- Session management
    require_ip_whitelist BOOLEAN DEFAULT FALSE,
    allowed_ips INET[],
    
    -- Audit
    last_login_at TIMESTAMP WITH TIME ZONE,
    last_login_ip INET,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES admin_users(id)
);

-- Indexes
CREATE INDEX idx_admin_email ON admin_users(email);
CREATE INDEX idx_admin_role ON admin_users(role);
CREATE INDEX idx_admin_active ON admin_users(is_active) WHERE is_active = TRUE;
```

### 5.7 Session Management Table

```sql
-- Database-backed sessions (fallback for Redis)
CREATE TABLE sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id UUID NOT NULL,
    user_type VARCHAR(20) NOT NULL CHECK (user_type IN ('voter', 'admin')),
    
    -- Session data
    data JSONB NOT NULL DEFAULT '{}',
    
    -- Security
    ip_address INET NOT NULL,
    user_agent_hash VARCHAR(64),
    
    -- Timing
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Status
    is_valid BOOLEAN DEFAULT TRUE,
    invalidated_at TIMESTAMP WITH TIME ZONE,
    invalidation_reason VARCHAR(50)
);

-- Indexes
CREATE INDEX idx_sessions_user ON sessions(user_id, user_type);
CREATE INDEX idx_sessions_expires ON sessions(expires_at) WHERE is_valid = TRUE;
CREATE INDEX idx_sessions_valid ON sessions(is_valid, expires_at);

-- Cleanup old sessions
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM sessions 
    WHERE expires_at < CURRENT_TIMESTAMP 
       OR (is_valid = FALSE AND invalidated_at < CURRENT_TIMESTAMP - INTERVAL '7 days');
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;
```

---

## 6. API Specifications

### 6.1 API Overview

```yaml
Base URL: https://api.fesu-ww.org/v1
Protocol: HTTPS only
Authentication: Bearer JWT
Rate Limiting: 100 requests/minute (general), 5 requests/15min (auth)
Content-Type: application/json
API Version: 1.0.0
```

### 6.2 Authentication Endpoints

#### POST /auth/register
Register a new voter account.

**Request:**
```json
{
  "email": "voter@example.com",
  "password": "SecureP@ssw0rd123",
  "firstName": "John",
  "lastName": "Doe",
  "studentId": "FESU123456",
  "phone": "+2348012345678",
  "dateOfBirth": "1995-05-15",
  "graduationYear": 2020,
  "chapter": "Lagos Chapter"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Registration successful. Please verify your email.",
  "data": {
    "userId": "550e8400-e29b-41d4-a716-446655440000",
    "email": "voter@example.com",
    "verificationTokenExpiry": "2025-01-15T12:00:00Z"
  }
}
```

**Error Responses:**
| Code | Description |
|------|-------------|
| 400 | Validation failed |
| 409 | Email or student ID already exists |
| 429 | Rate limit exceeded |

---

#### POST /auth/login
Authenticate user and receive JWT tokens.

**Request:**
```json
{
  "email": "voter@example.com",
  "password": "SecureP@ssw0rd123"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "accessToken": "eyJhbGciOiJSUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJSUzI1NiIs...",
    "expiresIn": 900,
    "requiresMFA": true,
    "mfaToken": "temp_mfa_token_xyz"
  }
}
```

**Error Responses:**
| Code | Description |
|------|-------------|
| 401 | Invalid credentials |
| 403 | Account blocked or not verified |
| 429 | Too many login attempts |

---

#### POST /auth/mfa/verify
Verify TOTP code for MFA.

**Request:**
```json
{
  "mfaToken": "temp_mfa_token_xyz",
  "totpCode": "123456"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "MFA verification successful",
  "data": {
    "accessToken": "eyJhbGciOiJSUzI1NiIs...",
    "refreshToken": "eyJhbGciOiJSUzI1NiIs...",
    "expiresIn": 900
  }
}
```

---

#### POST /auth/mfa/setup
Setup TOTP for account.

**Headers:**
```
Authorization: Bearer <access_token>
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "secret": "JBSWY3DPEHPK3PXP",
    "qrCodeUrl": "data:image/png;base64,iVBORw0KGgo...",
    "backupCodes": ["A1B2C3D4", "E5F6G7H8", "..."]
  }
}
```

---

#### POST /auth/refresh
Refresh access token using refresh token.

**Request:**
```json
{
  "refreshToken": "eyJhbGciOiJSUzI1NiIs..."
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGciOiJSUzI1NiIs...",
    "expiresIn": 900
  }
}
```

---

#### POST /auth/logout
Logout and invalidate tokens.

**Headers:**
```
Authorization: Bearer <access_token>
```

**Request:**
```json
{
  "refreshToken": "eyJhbGciOiJSUzI1NiIs..."
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Logout successful"
}
```

### 6.3 Voting Endpoints

#### GET /elections
List all elections.

**Headers:**
```
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| status | string | Filter by status: upcoming, active, completed |
| page | integer | Page number (default: 1) |
| limit | integer | Items per page (default: 20, max: 100) |

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "elections": [
      {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "name": "FESU-WW 2026 General Elections",
        "description": "Annual election for executive positions",
        "startDate": "2026-03-01T08:00:00Z",
        "endDate": "2026-03-07T18:00:00Z",
        "status": "active",
        "positions": [
          {
            "id": "pos-001",
            "name": "President",
            "description": "Head of the student union",
            "candidateCount": 5
          }
        ]
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 5,
      "totalPages": 1
    }
  }
}
```

---

#### GET /elections/:id
Get detailed election information.

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "FESU-WW 2026 General Elections",
    "description": "Annual election for executive positions",
    "startDate": "2026-03-01T08:00:00Z",
    "endDate": "2026-03-07T18:00:00Z",
    "status": "active",
    "hasVoted": false,
    "positions": [
      {
        "id": "pos-001",
        "name": "President",
        "description": "Head of the student union",
        "maxSelections": 1,
        "candidates": [
          {
            "id": "cand-001",
            "ballotNumber": 1,
            "name": "Jane Smith",
            "photoUrl": "https://cdn.fesu-ww.org/candidates/jane.jpg",
            "manifestoSummary": "Dedicated to student welfare...",
            "qualifications": ["MBA", "Former VP"]
          }
        ]
      }
    ]
  }
}
```

---

#### POST /votes/submit
Submit a vote.

**Headers:**
```
Authorization: Bearer <access_token>
Content-Type: application/json
```

**Request:**
```json
{
  "electionId": "550e8400-e29b-41d4-a716-446655440000",
  "selections": [
    {
      "positionId": "pos-001",
      "candidateId": "cand-001"
    },
    {
      "positionId": "pos-002",
      "candidateId": "cand-005"
    }
  ],
  "confirmation": {
    "acknowledged": true,
    "understandIrreversible": true
  }
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Vote recorded successfully",
  "data": {
    "receiptId": "receipt-abc123",
    "blockchainTxHash": "0x1234567890abcdef...",
    "blockchainBlockNumber": 12345678,
    "timestamp": "2026-03-01T10:30:00Z",
    "verificationUrl": "https://election.fesu-ww.org/verify/receipt-abc123"
  }
}
```

**Error Responses:**
| Code | Description |
|------|-------------|
| 400 | Invalid vote data or already voted |
| 401 | Authentication required |
| 403 | Election not active or not eligible |
| 409 | Already voted for this position |
| 429 | Rate limit exceeded |

---

#### GET /votes/verify/:receiptId
Verify a vote using receipt ID.

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "verified": true,
    "electionId": "550e8400-e29b-41d4-a716-446655440000",
    "electionName": "FESU-WW 2026 General Elections",
    "blockchainTxHash": "0x1234567890abcdef...",
    "blockchainBlockNumber": 12345678,
    "blockchainTimestamp": "2026-03-01T10:30:15Z",
    "voteTimestamp": "2026-03-01T10:30:00Z"
  }
}
```

### 6.4 Admin Endpoints

#### POST /admin/elections
Create a new election (Admin only).

**Headers:**
```
Authorization: Bearer <admin_access_token>
```

**Request:**
```json
{
  "name": "FESU-WW 2026 General Elections",
  "description": "Annual election for executive positions",
  "startDate": "2026-03-01T08:00:00Z",
  "endDate": "2026-03-07T18:00:00Z",
  "positions": [
    {
      "name": "President",
      "description": "Head of the student union",
      "maxSelections": 1
    },
    {
      "name": "Vice President",
      "description": "Deputy head",
      "maxSelections": 1
    }
  ]
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "message": "Election created successfully",
  "data": {
    "electionId": "550e8400-e29b-41d4-a716-446655440000",
    "blockchainElectionId": 42,
    "status": "draft",
    "createdAt": "2025-01-15T10:00:00Z"
  }
}
```

---

#### GET /admin/elections/:id/results
Get election results (Admin only).

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "electionId": "550e8400-e29b-41d4-a716-446655440000",
    "electionName": "FESU-WW 2026 General Elections",
    "status": "completed",
    "totalVotes": 15420,
    "turnoutPercentage": 78.5,
    "positions": [
      {
        "positionId": "pos-001",
        "positionName": "President",
        "totalVotes": 15420,
        "candidates": [
          {
            "candidateId": "cand-001",
            "name": "Jane Smith",
            "ballotNumber": 1,
            "voteCount": 8234,
            "percentage": 53.4,
            "isWinner": true
          },
          {
            "candidateId": "cand-002",
            "name": "John Doe",
            "ballotNumber": 2,
            "voteCount": 7186,
            "percentage": 46.6,
            "isWinner": false
          }
        ]
      }
    ],
    "blockchainVerification": {
      "contractAddress": "0x1234567890abcdef...",
      "totalOnChainVotes": 15420,
      "verificationStatus": "verified"
    }
  }
}
```

---

#### GET /admin/audit/logs
Get audit logs (Auditor only).

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| startDate | ISO8601 | Filter from date |
| endDate | ISO8601 | Filter to date |
| eventType | string | Filter by event type |
| actorId | UUID | Filter by actor |
| page | integer | Page number |
| limit | integer | Items per page |

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "logs": [
      {
        "id": 12345,
        "eventType": "VOTE_CAST",
        "eventCategory": "voting",
        "actorType": "voter",
        "action": "submit_vote",
        "resourceType": "vote",
        "ipAddress": "192.168.1.1",
        "success": true,
        "createdAt": "2026-03-01T10:30:00Z",
        "logHash": "a1b2c3d4e5f6...",
        "previousLogHash": "z9y8x7w6v5u..."
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 50,
      "total": 15420
    }
  }
}
```

### 6.5 Audit Endpoints

#### GET /audit/election/:id/verify
Public election verification endpoint.

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "electionId": "550e8400-e29b-41d4-a716-446655440000",
    "electionName": "FESU-WW 2026 General Elections",
    "verification": {
      "blockchainContract": "0x1234567890abcdef...",
      "totalVotesRecorded": 15420,
      "totalVotesOnChain": 15420,
      "verificationHash": "sha256:abc123...",
      "lastVerifiedAt": "2026-03-08T00:00:00Z",
      "status": "verified"
    },
    "transparency": {
      "auditReportUrl": "https://election.fesu-ww.org/audit/2026-report.pdf",
      "blockchainExplorerUrl": "https://polygonscan.com/address/0x123..."
    }
  }
}
```

### 6.6 Error Codes and Responses

#### Standard Error Response Format
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {},
    "requestId": "req-uuid-123",
    "timestamp": "2026-03-01T10:30:00Z"
  }
}
```

#### Error Code Reference

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `UNAUTHORIZED` | 401 | Authentication required or invalid credentials |
| `FORBIDDEN` | 403 | Insufficient permissions |
| `NOT_FOUND` | 404 | Resource not found |
| `VALIDATION_ERROR` | 400 | Request validation failed |
| `RATE_LIMITED` | 429 | Too many requests |
| `ELECTION_NOT_ACTIVE` | 403 | Election is not currently active |
| `ALREADY_VOTED` | 409 | Voter has already cast vote |
| `INVALID_TOTP` | 401 | Invalid TOTP code |
| `ACCOUNT_BLOCKED` | 403 | Account has been blocked |
| `MFA_REQUIRED` | 401 | Multi-factor authentication required |
| `INTERNAL_ERROR` | 500 | Internal server error |
| `SERVICE_UNAVAILABLE` | 503 | Service temporarily unavailable |
| `BLOCKCHAIN_ERROR` | 502 | Blockchain transaction failed |
| `INVALID_SIGNATURE` | 400 | Invalid cryptographic signature |

---

## 7. Deployment Guide

### 7.1 Server Requirements

#### Production Environment

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| **Application Servers** | 3x t3.large | 3x c6i.xlarge |
| **Database (PostgreSQL)** | db.r6g.xlarge | db.r6g.2xlarge |
| **Cache (Redis)** | cache.r6g.large | cache.r6g.xlarge (cluster) |
| **Load Balancer** | Application LB | Application LB + WAF |
| **Storage** | 500GB SSD | 1TB SSD + S3 |
| **Network** | 1Gbps | 10Gbps |

#### System Specifications (Per Application Server)

```yaml
Operating System: Ubuntu Server 22.04 LTS
CPU: 4+ cores (x86_64)
Memory: 8GB RAM minimum
Disk: 100GB SSD (root) + 500GB (data)
Network: Dual NIC (public/private)
```

### 7.2 Step-by-Step Deployment Instructions

#### Step 1: Infrastructure Setup

```bash
# 1. Create VPC and subnets
aws ec2 create-vpc --cidr-block 10.0.0.0/16

# 2. Create security groups
aws ec2 create-security-group \
  --group-name fesu-ww-app-sg \
  --description "Application security group"

# 3. Configure security group rules
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxxxxxx \
  --protocol tcp \
  --port 443 \
  --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxxxxxx \
  --protocol tcp \
  --port 22 \
  --cidr 10.0.0.0/8
```

#### Step 2: Database Setup

```bash
# Create RDS PostgreSQL instance
aws rds create-db-instance \
  --db-instance-identifier fesu-ww-production \
  --db-instance-class db.r6g.xlarge \
  --engine postgres \
  --engine-version 16.1 \
  --allocated-storage 500 \
  --storage-type gp3 \
  --storage-encrypted \
  --master-username fesu_admin \
  --master-user-password '<STRONG_PASSWORD>' \
  --vpc-security-group-ids sg-xxxxxxxxx \
  --backup-retention-period 30 \
  --preferred-backup-window 03:00-04:00 \
  --enable-performance-insights \
  --performance-insights-retention-period 7 \
  --enable-cloudwatch-logs-exports 'postgresql' \
  --deletion-protection

# Create Redis cluster
aws elasticache create-replication-group \
  --replication-group-id fesu-ww-redis \
  --replication-group-description "FESU-WW Session Cache" \
  --engine redis \
  --cache-node-type cache.r6g.large \
  --num-cache-clusters 3 \
  --automatic-failover-enabled \
  --multi-az-enabled \
  --at-rest-encryption-enabled \
  --transit-encryption-enabled
```

#### Step 3: Application Deployment

```bash
# Clone repository
git clone https://github.com/fesu-ww/election-portal.git
cd election-portal

# Install dependencies
npm ci --production

# Build application
npm run build

# Run database migrations
npx prisma migrate deploy

# Generate Prisma client
npx prisma generate

# Start application with PM2
pm2 start dist/server.js \
  --name fesu-ww-api \
  --instances max \
  --exec-mode cluster \
  --env production

# Save PM2 configuration
pm2 save
pm2 startup systemd
```

### 7.3 Environment Configuration

#### Production Environment Variables (.env.production)

```bash
# Application
NODE_ENV=production
PORT=3000
API_VERSION=v1
LOG_LEVEL=info

# Database
DATABASE_URL=postgresql://fesu_admin:<PASSWORD>@fesu-ww-production.XXXXXXXX.us-east-1.rds.amazonaws.com:5432/fesu_election?schema=public
DATABASE_SSL=true
DATABASE_POOL_SIZE=20

# Redis
REDIS_URL=rediss://fesu-ww-redis.XXX.cache.amazonaws.com:6379
REDIS_PASSWORD=<REDIS_PASSWORD>
REDIS_TLS=true

# JWT
JWT_PRIVATE_KEY_PATH=/etc/fesu-ww/keys/jwt-private.pem
JWT_PUBLIC_KEY_PATH=/etc/fesu-ww/keys/jwt-public.pem
JWT_ACCESS_TOKEN_EXPIRY=15m
JWT_REFRESH_TOKEN_EXPIRY=7d

# Encryption
ENCRYPTION_KEY=<32_BYTE_HEX_KEY>
TOTP_ENCRYPTION_KEY=<32_BYTE_HEX_KEY>

# Blockchain
BLOCKCHAIN_RPC_URL=https://polygon-rpc.com
BLOCKCHAIN_CONTRACT_ADDRESS=0x...
BLOCKCHAIN_PRIVATE_KEY=<ORACLE_PRIVATE_KEY>
BLOCKCHAIN_CHAIN_ID=137

# External Services
SENDGRID_API_KEY=SG.xxxxx
TWILIO_ACCOUNT_SID=ACxxxxx
TWILIO_AUTH_TOKEN=xxxxx
TWILIO_PHONE_NUMBER=+1xxxxx

# Security
CORS_ORIGIN=https://election.fesu-ww.org
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_REQUESTS=100

# Monitoring
DATADOG_API_KEY=xxxxx
SENTRY_DSN=https://xxxxx@xxxxx.ingest.sentry.io/xxxxx
```

### 7.4 SSL Certificate Setup

#### Using Let's Encrypt

```bash
# Install Certbot
sudo apt update
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot certonly \
  --nginx \
  -d election.fesu-ww.org \
  -d api.fesu-ww.org \
  -d admin.fesu-ww.org \
  --agree-tos \
  --email admin@fesu-ww.org \
  --non-interactive

# Auto-renewal (already configured by certbot)
sudo systemctl status certbot.timer

# Test renewal
sudo certbot renew --dry-run
```

#### Using AWS Certificate Manager

```bash
# Request certificate
aws acm request-certificate \
  --domain-name election.fesu-ww.org \
  --subject-alternative-names api.fesu-ww.org admin.fesu-ww.org \
  --validation-method DNS \
  --idempotency-token fesu-ww-2026

# Add DNS validation records (in Route 53)
# Wait for certificate validation
aws acm describe-certificate --certificate-arn arn:aws:acm:...
```

### 7.5 Smart Contract Deployment

```javascript
// scripts/deploy-contract.js
const { ethers } = require('ethers');
const fs = require('fs');

async function deployContract() {
  // Connect to Polygon network
  const provider = new ethers.JsonRpcProvider(process.env.BLOCKCHAIN_RPC_URL);
  const wallet = new ethers.Wallet(process.env.DEPLOYER_PRIVATE_KEY, provider);
  
  console.log('Deploying from:', wallet.address);
  
  // Load contract artifact
  const contractJson = JSON.parse(
    fs.readFileSync('./artifacts/contracts/FESUElection.sol/FESUElection.json')
  );
  
  // Deploy contract
  const factory = new ethers.ContractFactory(
    contractJson.abi,
    contractJson.bytecode,
    wallet
  );
  
  const contract = await factory.deploy();
  await contract.waitForDeployment();
  
  const contractAddress = await contract.getAddress();
  console.log('Contract deployed to:', contractAddress);
  
  // Verify deployment
  const receipt = await provider.getTransactionReceipt(contract.deploymentTransaction().hash);
  console.log('Block number:', receipt.blockNumber);
  
  // Grant oracle role to application wallet
  const oracleWallet = process.env.BLOCKCHAIN_ORACLE_ADDRESS;
  const ORACLE_ROLE = await contract.ORACLE_ROLE();
  const grantTx = await contract.grantRole(ORACLE_ROLE, oracleWallet);
  await grantTx.wait();
  console.log('Oracle role granted to:', oracleWallet);
  
  // Save deployment info
  const deploymentInfo = {
    network: 'polygon',
    contractAddress,
    deployer: wallet.address,
    oracle: oracleWallet,
    blockNumber: receipt.blockNumber,
    timestamp: new Date().toISOString()
  };
  
  fs.writeFileSync(
    './deployment-info.json',
    JSON.stringify(deploymentInfo, null, 2)
  );
  
  return deploymentInfo;
}

deployContract()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
```

---

## 8. Security Checklist

### 8.1 Pre-Deployment Security Checks

#### Code Security
- [ ] All dependencies scanned with `npm audit`
- [ ] No hardcoded secrets in codebase
- [ ] Environment variables properly configured
- [ ] Input validation implemented on all endpoints
- [ ] SQL injection prevention (parameterized queries)
- [ ] XSS protection (output encoding)
- [ ] CSRF tokens implemented for state-changing operations

#### Infrastructure Security
- [ ] TLS 1.3 configured and enforced
- [ ] HSTS header enabled
- [ ] Security headers configured (CSP, X-Frame-Options, etc.)
- [ ] Database encryption at rest enabled
- [ ] Database SSL connections enforced
- [ ] Redis encryption in transit enabled
- [ ] Firewall rules configured (deny all, allow specific)
- [ ] DDoS protection enabled

#### Authentication & Authorization
- [ ] Password policy enforced (min 12 chars, complexity)
- [ ] MFA enabled for all admin accounts
- [ ] JWT tokens use RS256 algorithm
- [ ] Token expiration configured (15 min access, 7 day refresh)
- [ ] Session management implemented
- [ ] Rate limiting configured
- [ ] Account lockout after failed attempts

### 8.2 Penetration Testing Requirements

#### Required Tests

| Test Type | Frequency | Provider | Scope |
|-----------|-----------|----------|-------|
| **Vulnerability Scan** | Weekly | Automated (Snyk) | Full codebase |
| **SAST** | Every commit | SonarQube | Source code |
| **DAST** | Weekly | OWASP ZAP | Running application |
| **Penetration Test** | Quarterly | Third-party | Full system |
| **Infrastructure Audit** | Bi-annually | Third-party | Cloud infrastructure |

#### OWASP Top 10 Coverage

| Risk | Mitigation | Verification |
|------|------------|--------------|
| A01: Broken Access Control | RBAC, JWT validation | Pen test |
| A02: Cryptographic Failures | AES-256, TLS 1.3, RS256 | Code review |
| A03: Injection | Parameterized queries, input validation | SAST/DAST |
| A04: Insecure Design | Threat modeling, secure SDLC | Architecture review |
| A05: Security Misconfiguration | Hardening guides, IaC | Config audit |
| A06: Vulnerable Components | Dependency scanning | Automated scan |
| A07: Auth Failures | MFA, strong passwords, session mgmt | Pen test |
| A08: Data Integrity Failures | Blockchain verification | Code review |
| A09: Logging Failures | Comprehensive audit logging | Log review |
| A10: SSRF | URL validation, network segmentation | Pen test |

### 8.3 Compliance Requirements

#### GDPR Compliance

| Requirement | Implementation |
|-------------|----------------|
| **Lawful Basis** | Consent obtained during registration |
| **Data Minimization** | Only collect necessary voter data |
| **Purpose Limitation** | Data used only for election purposes |
| **Storage Limitation** | Auto-delete after retention period |
| **Accuracy** | Voters can update their information |
| **Integrity & Confidentiality** | Encryption, access controls |
| **Accountability** | Audit logs, DPO appointment |

#### Data Protection Measures

```yaml
Data Classification:
  - Critical: Vote data (anonymized), private keys
  - Sensitive: Personal information, authentication data
  - Internal: Election configuration, audit logs
  - Public: Election results, candidate information

Retention Policy:
  - Voter personal data: 2 years after last election
  - Vote records: Permanent (anonymized)
  - Audit logs: 7 years
  - Session data: 30 days

Data Subject Rights:
  - Right to access: /api/user/data-export
  - Right to rectification: /api/user/profile
  - Right to erasure: /api/user/delete (with restrictions)
  - Right to portability: JSON export available
```

---

## 9. Maintenance & Monitoring

### 9.1 Backup Procedures

#### Database Backup Strategy

```bash
#!/bin/bash
# /opt/fesu-ww/scripts/backup-database.sh

set -e

BACKUP_DIR="/backup/postgresql"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="fesu_ww_${TIMESTAMP}.sql.gz"
RETENTION_DAYS=30

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Perform backup
pg_dump "$DATABASE_URL" | gzip > "$BACKUP_DIR/$BACKUP_FILE"

# Verify backup
if gunzip -t "$BACKUP_DIR/$BACKUP_FILE"; then
    echo "Backup verified: $BACKUP_FILE"
else
    echo "Backup verification failed!"
    exit 1
fi

# Upload to S3
aws s3 cp "$BACKUP_DIR/$BACKUP_FILE" "s3://fesu-ww-backups/database/"

# Clean up old backups (local)
find "$BACKUP_DIR" -name "fesu_ww_*.sql.gz" -mtime +7 -delete

# Clean up old backups (S3)
aws s3 ls "s3://fesu-ww-backups/database/" | \
    awk '{print $4}' | \
    while read file; do
        aws s3api head-object --bucket fesu-ww-backups --key "database/$file" | \
        jq -r '.LastModified' | \
        xargs -I {} date -d {} +%s | \
        awk -v now=$(date +%s) -v retention=$((RETENTION_DAYS * 86400)) \
            'now - $1 > retention {print "database/" file}' | \
        xargs -I {} aws s3 rm "s3://fesu-ww-backups/{}"
    done

echo "Backup completed: $BACKUP_FILE"
```

#### Backup Schedule

| Backup Type | Frequency | Retention | Storage |
|-------------|-----------|-----------|---------|
| **Automated RDS** | Daily | 30 days | AWS RDS |
| **Manual Full** | Weekly | 90 days | S3 Glacier |
| **Point-in-Time** | Continuous | 7 days | RDS |
| **Pre-Election** | Before each election | Permanent | S3 + Offsite |

### 9.2 Monitoring Setup

#### Prometheus Configuration

```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

alerting:
  alertmanagers:
    - static_configs:
        - targets: ['alertmanager:9093']

rule_files:
  - /etc/prometheus/rules/*.yml

scrape_configs:
  - job_name: 'fesu-ww-api'
    static_configs:
      - targets: ['api-1:3000', 'api-2:3000', 'api-3:3000']
    metrics_path: /metrics
    scrape_interval: 10s

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis-exporter:9121']

  - job_name: 'node'
    static_configs:
      - targets: ['node-exporter:9100']
```

#### Key Metrics to Monitor

| Metric | Threshold | Alert Severity |
|--------|-----------|----------------|
| API Response Time | > 500ms | Warning |
| API Error Rate | > 1% | Critical |
| Database Connections | > 80% | Warning |
| Redis Memory Usage | > 85% | Warning |
| Failed Login Attempts | > 10/min | Critical |
| Blockchain Sync Lag | > 5 blocks | Warning |
| SSL Certificate Expiry | < 30 days | Warning |

### 9.3 Incident Response Plan

#### Incident Severity Levels

| Level | Description | Response Time | Examples |
|-------|-------------|---------------|----------|
| **P1 - Critical** | System down, data breach | 15 minutes | Database failure, security breach |
| **P2 - High** | Major functionality impaired | 1 hour | API outage, blockchain sync failure |
| **P3 - Medium** | Minor functionality affected | 4 hours | Performance degradation, non-critical bug |
| **P4 - Low** | Cosmetic issues | 24 hours | UI glitches, documentation errors |

#### Incident Response Workflow

```
1. DETECTION
   ↓
2. ASSESSMENT (Determine severity)
   ↓
3. CONTAINMENT (Stop the bleeding)
   ↓
4. ERADICATION (Fix the root cause)
   ↓
5. RECOVERY (Restore normal operations)
   ↓
6. POST-INCIDENT (Review and document)
```

#### Emergency Contacts

| Role | Name | Phone | Email |
|------|------|-------|-------|
| **Incident Commander** | TBD | +xxx | incident@fesu-ww.org |
| **Technical Lead** | TBD | +xxx | tech-lead@fesu-ww.org |
| **Security Officer** | TBD | +xxx | security@fesu-ww.org |
| **Cloud Provider** | AWS Support | - | support@aws.amazon.com |

---

## 10. Appendices

### 10.1 Glossary of Terms

| Term | Definition |
|------|------------|
| **AES-256** | Advanced Encryption Standard with 256-bit key |
| **Blockchain** | Distributed ledger technology for immutable records |
| **DDoS** | Distributed Denial of Service attack |
| **GDPR** | General Data Protection Regulation (EU) |
| **HSTS** | HTTP Strict Transport Security |
| **JWT** | JSON Web Token for authentication |
| **MFA** | Multi-Factor Authentication |
| **Nullifier** | Cryptographic value preventing double voting |
| **RBAC** | Role-Based Access Control |
| **SLA** | Service Level Agreement |
| **TOTP** | Time-based One-Time Password |
| **TLS** | Transport Layer Security |
| **Zero-Knowledge Proof** | Cryptographic method proving knowledge without revealing data |

### 10.2 Contact Information

#### FESU-WW Technical Committee

| Role | Contact |
|------|---------|
| **Project Manager** | pm@fesu-ww.org |
| **Technical Lead** | tech-lead@fesu-ww.org |
| **Security Officer** | security@fesu-ww.org |
| **DevOps Team** | devops@fesu-ww.org |
| **Support Desk** | support@fesu-ww.org |

#### External Vendors

| Vendor | Service | Contact |
|--------|---------|---------|
| AWS | Cloud Infrastructure | aws-support@amazon.com |
| Cloudflare | CDN & Security | support@cloudflare.com |
| Polygon | Blockchain | support@polygon.technology |

### 10.3 Version History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 0.1.0 | 2025-01-01 | Technical Team | Initial draft |
| 0.2.0 | 2025-01-05 | Security Team | Added security specifications |
| 0.3.0 | 2025-01-10 | DevOps Team | Added deployment guide |
| 1.0.0 | 2025-01-15 | Technical Committee | Final release |

---

## Document Control

**Document Owner:** FESU-WW Technical Committee  
**Review Cycle:** Quarterly  
**Next Review Date:** April 2025  
**Approval Status:** Pending

---

*This document contains confidential and proprietary information. Unauthorized distribution is prohibited.*

**© 2025 Federation of Ekureku Students Union World-Wide. All rights reserved.**
